(() => {
const D = window.REPLATE_DATA;
const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const store = {
  get(k, d){ try{ const v = localStorage.getItem("replate2."+k); return v ? JSON.parse(v) : d; }catch{ return d; } },
  set(k, v){ try{ localStorage.setItem("replate2."+k, JSON.stringify(v)); }catch{} }
};
const uid = p => p + Math.random().toString(36).slice(2,9);

/* ---------- Capabilities ---------- */
const cap = { sample:null, dictation:null, tts:null, images:false };
if (window.claude?.use) {
  window.claude.use("sample").then(async s => { cap.sample = s; if (s) { try { cap.images = !!(await s.limits())?.images; } catch {} } refreshAvailability(); });
  window.claude.use("dictation").then(d => { cap.dictation = d; setupDictation(); refreshAvailability(); });
  window.claude.use("tts").then(t => { cap.tts = t; });
}
async function askJSON(prompt, opts={}){ if (!cap.sample) throw { code:"unavailable" }; return cap.sample.json(prompt, opts); }
const errMsg = e => e?.code === "not_granted" ? "Claude access was declined for this page. You can allow it from the artifact's Permissions menu."
  : e?.code === "rate_limited" ? "Too many requests right now. Wait a minute and try again."
  : e?.code === "unavailable" ? "AI generation needs this page open on claude.ai with Claude access allowed."
  : "Something went wrong reaching the assistant. Try again in a moment.";
const loadingHTML = t => `<div class="loading"><span class="dots"><i></i><i></i><i></i></span>${esc(t)}</div>`;

/* ---------- Ingredients, photos, nutrition ---------- */
const ingName = k => D.ING[k]?.[0] || k;
const ingPhoto = k => D.PHOTO_I.has(k) ? `img/i/${k}.jpg` : null;
const dishPhoto = k => D.DISH[k] ? `img/d/${k}.jpg` : null;
function thumb(k, name, cls="th"){
  const src = k && ingPhoto(k);
  return src ? `<img class="${cls}" src="${src}" alt="" loading="lazy">` : `<span class="${cls} th-none" aria-hidden="true">${esc(((name||k||"?").trim()[0]||"?").toUpperCase())}</span>`;
}
const norm = s => String(s||"").toLowerCase().replace(/[^a-zऀ-ॿ؀-ۿ ]/g," ").replace(/\s+/g," ").trim();
function matchKey(name){
  const n = norm(name); if (!n) return null;
  if (D.ING[n.replace(/ /g,"_")]) return n.replace(/ /g,"_");
  let best = null;
  for (const [k,[nm,,,,al]] of Object.entries(D.ING)) {
    const names = [norm(nm), ...norm(al).split(" ").filter(Boolean), norm(k.replace(/_/g," "))];
    if (names.includes(n) || names.includes(n.replace(/e?s$/,""))) return k;
    if (!best && (norm(nm).includes(n) || n.includes(norm(nm)))) best = k;
  }
  if (best) return best;
  for (const [k,[nm,,,,al]] of Object.entries(D.ING)) { if (norm(al) && n.split(" ").some(w => w.length > 3 && norm(al).split(" ").includes(w))) return k; }
  return null;
}
const parseIngs = s => s.split("|").map(x => { const [k,g,...l] = x.split(":"); return { k, g:+g, label:l.join(":") || ingName(k) }; });
function aiIngs(list){ return (list||[]).map(i => { let k = i.k && D.ING[i.k] ? i.k : matchKey(i.name); return { k, g: Math.max(0, +i.g || 0), label: [i.qty, i.name].filter(Boolean).join(" ") || ingName(k) }; }); }
function nutrition(ings, serves=1){
  const t = [0,0,0,0,0,0,0,0], missing = [];
  ings.forEach(i => { const e = D.ING[i.k]; if (!e) { if (i.g >= 5) missing.push(i.label); return; } e[2].forEach((v,j) => t[j] += v * i.g / 100); });
  return { v: t.map(x => x / Math.max(1, serves)), missing };
}
const fmtN = (v, j) => j === 0 ? Math.round(v) : (v < 10 ? (Math.round(v*10)/10) : Math.round(v));
const NUT = D.NUT;

/* Profile targets: Mifflin–St Jeor energy + ICMR-NIN 2020 reference intakes (approximate) */
function targets(p){
  if (!p) return null;
  const w = +p.weight || 60, h = +p.height || 160, a = +p.age || 40, female = p.sex !== "male";
  const af = { sedentary:1.2, light:1.375, moderate:1.55, active:1.725 }[p.activity] || 1.375;
  let kcal = (10*w + 6.25*h - 5*a + (female ? -161 : 5)) * af;
  if (p.goals?.includes("Lose weight")) kcal = Math.max(1200, kcal - 400);
  if (p.goals?.includes("Gain weight / muscle")) kcal += 300;
  const preg = p.conditions?.includes("Pregnancy"), bf = p.conditions?.includes("Breastfeeding");
  if (preg) kcal += 350; if (bf) kcal += 500;
  const diab = p.conditions?.some(c => /diabetes/i.test(c));
  return [ kcal, w * (a >= 60 || preg ? 1.0 : 0.83), kcal * (diab ? .45 : .5) / 4, kcal * .3 / 9, Math.round(kcal / 1000 * 14),
    preg ? 27 : (female && a < 50 ? 29 : 19), female && a >= 50 ? 1200 : 1000, 2.5 ];
}

/* ---------- Allergy / diet safety checks ---------- */
const DAIRY = ["milk","yoghurt","paneer","ghee","labneh","cheese","khoya","cream","butter"];
const GLUTEN = ["atta","maida","semolina","vermicelli","khubz","bulgur","bread","kataifi"];
const MEAT = ["chicken","lamb","fish","prawns"];
const ROOTS = ["onion","garlic","potato","carrot","beetroot","ginger","sweet_potato"];
const RE = {
  dairy:/\b(milk|yogh?urt|curd|paneer|ghee|butter|cream|cheese|khoya|mawa|labneh|halloumi|rabri|malai|lassi|chaas|buttermilk|dahi)\b/i,
  dairyEx:/coconut milk|soy milk|soya milk|oat milk|almond milk|peanut butter|coconut cream/i,
  gluten:/wheat|atta|maida|semolina|\brava\b|sooji|suji|vermicelli|seviyan|bread|khubz|bulgur|dalia|daliya|barley|kataifi|\bpav\b|\broti|chapati|phulka|paratha|naan|thepla|regag|khameer|chebab|pasta|noodle/i,
  meat:/chicken|mutton|\blamb\b|beef|goat|fish|prawn|shrimp|\bmeat|keema|hammour|kingfish|tuna|crab|squid|gelatin/i,
  egg:/\beggs?\b|omelette|\banda\b/i,
  roots:/\b(onions?|garlic|potato(es)?|carrots?|beet(root)?s?|ginger|radish|shallots?)\b/i,
};
const ALLERGY = {
  "Tree nuts":{ k:["almonds","cashews","pistachio","walnuts"], re:/almond|cashew|pistachio|walnut|hazelnut|pecan|macadamia|\bkaju\b|badam|\bpista\b/i, ex:/coconut/i },
  "Peanuts":{ k:["peanuts"], re:/peanut|groundnut|moongphali/i },
  "Milk / dairy":{ k:DAIRY, re:RE.dairy, ex:RE.dairyEx },
  "Egg":{ k:["egg"], re:RE.egg },
  "Gluten / wheat":{ k:GLUTEN, re:RE.gluten, ex:/buckwheat/i },
  "Sesame":{ k:["sesame","tahini"], re:/sesame|tahini|\btil\b/i },
  "Fish":{ k:["fish"], re:/fish|salmon|tuna|hammour|kingfish|sardine|anchov|machli|\bmeen\b/i },
  "Shellfish":{ k:["prawns"], re:/prawn|shrimp|crab|lobster|squid|clam|mussel/i },
  "Soy":{ k:["tofu","soy_milk"], re:/\bsoy|soya|tofu/i },
};
function rulesFor(p){
  const r = [];
  (p.allergies||[]).forEach(a => ALLERGY[a] && r.push({ why:`allergy: ${a.toLowerCase()}`, ...ALLERGY[a] }));
  const d = p.diet;
  if (["Vegetarian","Vegan","Jain"].includes(d)) r.push({ why:`${d.toLowerCase()} diet`, k:[...MEAT,"egg"], re:new RegExp(RE.meat.source+"|"+RE.egg.source,"i") });
  if (d === "Eggetarian") r.push({ why:"eggetarian diet", k:MEAT, re:RE.meat });
  if (d === "Vegan") r.push({ why:"vegan diet", k:[...DAIRY,"honey"], re:new RegExp(RE.dairy.source+"|honey","i"), ex:RE.dairyEx });
  if (d === "Jain" || p.reqs?.includes("No onion or garlic")) r.push({ why: d === "Jain" ? "Jain diet (no root vegetables)" : "no onion or garlic", k: d === "Jain" ? ROOTS : ["onion","garlic"], re: d === "Jain" ? RE.roots : /onion|garlic|shallot/i });
  if (p.reqs?.includes("Halal")) r.push({ why:"halal", k:[], re:/pork|bacon|\bham\b|lard|wine|\brum\b|beer|gelatin/i });
  if (p.reqs?.includes("Gluten-free") || p.conditions?.includes("Coeliac disease")) r.push({ why:"gluten-free", k:[...GLUTEN,"oats"], re:RE.gluten, ex:/buckwheat/i });
  if (p.reqs?.includes("Dairy-free")) r.push({ why:"dairy-free", k:DAIRY, re:RE.dairy, ex:RE.dairyEx });
  if (p.conditions?.includes("Lactose intolerance")) r.push({ why:"lactose intolerance", k:["milk","cream","khoya"], re:/\bmilk\b|cream|khoya|mawa|rabri|malai/i, ex:RE.dairyEx });
  const terms = [p.avoid, p.allergyOther].join(",").split(/[,;\n]+/).map(s => s.trim().toLowerCase()).filter(s => s.length >= 3);
  terms.forEach(t => r.push({ why:`you asked to avoid ${t}`, k:[], re:new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"i") }));
  return r;
}
function conflictsOf(R, p){
  if (!p) return [];
  const rules = rulesFor(p), out = new Set();
  R.ings.forEach(i => {
    const text = `${i.label} ${i.k ? ingName(i.k) : ""}`;
    rules.forEach(rule => {
      const hitK = i.k && rule.k.includes(i.k);
      const hitT = rule.re.test(text) && !(rule.ex && rule.ex.test(text));
      if (hitK || hitT) out.add(`${i.label} (${rule.why})`);
    });
  });
  return [...out];
}
const keyConflicts = (k, p) => p ? conflictsOf({ ings:[{ k, g:1, label:ingName(k) }] }, p).length > 0 : false;
const MEAT_DISHES = new Set("chicken_tikka tandoori_chicken biryani haleem rogan_josh fish_curry grilled_fish chicken_curry machboos harees kabsa mandi shawarma shish_tawook kofta thareed".split(" "));
const EGG_DISHES = new Set("egg_bhurji shakshuka balaleet".split(" "));
const DAIRY_DISHES = new Set("paneer_tikka palak_paneer kheer gajar_halwa shrikhand lassi chaas raita curd_rice kadhi dal_makhani grilled_halloumi kunafa umm_ali".split(" "));
function dishLibrary(p, filter){
  return Object.entries(D.DISH).filter(([k,[,c]]) => {
    if (filter && !filter(c)) return false;
    if (!p) return true;
    if (["Vegetarian","Vegan","Jain","Eggetarian"].includes(p.diet) && MEAT_DISHES.has(k)) return false;
    if (["Vegetarian","Vegan","Jain"].includes(p.diet) && EGG_DISHES.has(k)) return false;
    if ((p.diet === "Vegan" || p.reqs?.includes("Dairy-free") || p.allergies?.includes("Milk / dairy")) && DAIRY_DISHES.has(k)) return false;
    return true;
  }).map(([k,[n]]) => `${k}: ${n}`).join("; ");
}
const ING_KEYS = Object.keys(D.ING).filter(k => !["salt","water","yeast"].includes(k)).join(", ");

/* ---------- Recipe images ---------- */
function imgFor(photo, ings, alt){
  if (photo && D.DISH[photo]) return { type:"single", src:dishPhoto(photo), alt: D.DISH[photo][0] };
  const srcs = [...new Set(ings.map(i => i.k).filter(k => k && ingPhoto(k)))].slice(0,4).map(ingPhoto);
  return srcs.length ? { type:"collage", srcs } : { type:"none", alt };
}
function imgHTML(img){
  if (!img || img.type === "none") return `<div class="ph" style="display:grid;place-items:center;color:var(--muted);font-weight:600">No photo</div>`;
  if (img.type === "single") return `<img class="ph" src="${img.src}" alt="${esc(img.alt||"")}" loading="lazy">`;
  if (img.type === "split") return `<div class="split"><img src="${img.a.src}" alt="${esc(img.a.label)}" loading="lazy"><img src="${img.b.src}" alt="${esc(img.b.label)}" loading="lazy"><span class="x">×</span><span class="lb l">${esc(img.a.label)}</span><span class="lb r">${esc(img.b.label)}</span></div>`;
  const s = img.srcs; const cells = [0,1,2,3].map(i => `<img src="${s[i % s.length]}" alt="" loading="lazy">`).join("");
  return `<div class="collage">${cells}<span class="cap">Made from these ingredients</span></div>`;
}

/* ---------- i18n, router, chrome ---------- */
const I18N = { en:{},
  hi:{ nHome:"होम", nRecipes:"स्मार्ट रेसिपी", nFusion:"भारतीय × अमीराती", nQuality:"गुणवत्ता जाँच", nCare:"रीप्लेट केयर", nCuisine:"व्यंजन", nVoice:"आवाज़",
       heroEyebrow:"एआई रसोई साथी", heroTitle:"जो है, उसी से पकाइए। <em>कुछ भी बर्बाद न करें।</em>",
       heroLead:"बताइए आपकी रसोई में क्या है और पाइए भारतीय, अमीराती और फ्यूज़न रेसिपी, जाँचिए खाना अभी ठीक है या नहीं, और अपनी सेहत के अनुसार भोजन सुझाव पाइए।",
       heroCta:"रेसिपी जनरेटर खोलें", heroCta2:"भारतीय × अमीराती फ्यूज़न आज़माएँ" },
  ar:{ nHome:"الرئيسية", nRecipes:"وصفات ذكية", nFusion:"هندي × إماراتي", nQuality:"فحص الجودة", nCare:"ريبليت كير", nCuisine:"المطابخ", nVoice:"المساعد الصوتي",
       heroEyebrow:"رفيقك الذكي في المطبخ", heroTitle:"اطبخ مما لديك. <em>ولا تهدر شيئًا.</em>",
       heroLead:"أخبر ريبليت بما في مطبخك واحصل على وصفات هندية وإماراتية ومدمجة، وتحقق مما إذا كان الطعام لا يزال صالحًا، واحصل على اقتراحات وجبات تناسب صحتك.",
       heroCta:"افتح مولّد الوصفات", heroCta2:"جرّب المطبخ الهندي الإماراتي" } };
const EN = {};
$$("[data-i18n]").forEach(el => EN[el.dataset.i18n] = el.textContent);
$$("[data-i18n-html]").forEach(el => EN[el.dataset.i18nHtml] = el.innerHTML);
const LANG_NAME = { en:"English", hi:"Hindi", ar:"Arabic", ta:"Tamil", ml:"Malayalam", ur:"Urdu" };
let uiLang = store.get("lang","en");
function applyLang(l){
  uiLang = I18N[l] ? l : "en"; const dict = I18N[uiLang];
  $$("[data-i18n]").forEach(el => el.textContent = dict[el.dataset.i18n] || EN[el.dataset.i18n]);
  $$("[data-i18n-html]").forEach(el => el.innerHTML = dict[el.dataset.i18nHtml] || EN[el.dataset.i18nHtml]);
  document.documentElement.lang = uiLang; document.documentElement.dir = uiLang === "ar" ? "rtl" : "ltr";
  $("#uiLang").value = uiLang; store.set("lang", uiLang);
}
$("#uiLang").addEventListener("change", e => applyLang(e.target.value));
const replyLang = () => LANG_NAME[uiLang];

const ROUTES = ["home","recipes","fusion","quality","care","cuisine","voice","credits"];
function route(){
  const r = (location.hash || "#home").slice(1), page = ROUTES.includes(r) ? r : "home";
  $$("[data-page]").forEach(p => p.hidden = p.dataset.page !== page);
  $$(".nav a").forEach(a => a.classList.toggle("on", a.getAttribute("href") === "#"+page));
  $("#nav").classList.remove("open"); $("#menuBtn").setAttribute("aria-expanded","false");
  if (page === "credits") loadCredits();
  closeDrawer(true);
  window.scrollTo(0,0);
}
window.addEventListener("hashchange", route);
$("#menuBtn").addEventListener("click", e => { const o = $("#nav").classList.toggle("open"); e.currentTarget.setAttribute("aria-expanded", o); });
const pop = $("#profilePop");
$("#profileBtn").addEventListener("click", e => { e.stopPropagation(); pop.hidden = !pop.hidden; e.currentTarget.setAttribute("aria-expanded", !pop.hidden); });
document.addEventListener("click", e => { if (!pop.hidden && !pop.contains(e.target)) pop.hidden = true; });
function applyTheme(){ document.documentElement.dataset.theme = "light"; }
$("#showSaved").onclick = () => { pop.hidden = true; careView = "saved"; location.hash = "#care"; renderCare(); };
$("#showProfile").onclick = () => { pop.hidden = true; careView = "profile"; location.hash = "#care"; renderCare(); };

/* ---------- Saved recipes (all kinds) ---------- */
let saved = store.get("saved", {});
const isSaved = id => !!saved[id];
function toggleSave(R){
  if (saved[R.id]) delete saved[R.id]; else saved[R.id] = R;
  store.set("saved", saved); updSaved();
  $$(`[data-save="${CSS.escape(R.id)}"]`).forEach(b => paintSave(b, isSaved(R.id)));
  if (location.hash === "#care") renderCareNav();
}
const heart = on => `<svg viewBox="0 0 24 24" fill="${on?"currentColor":"none"}" stroke="currentColor" stroke-width="2"><path d="M12 21s-7-4.4-9.3-9A5.2 5.2 0 0112 6.5 5.2 5.2 0 0121.3 12C19 16.6 12 21 12 21z"/></svg>`;
function paintSave(b, on){ b.setAttribute("aria-pressed", on); b.setAttribute("aria-label", on ? "Remove from saved" : "Save recipe"); if (b.classList.contains("dr-save")) b.innerHTML = heart(on).replace("<svg","<svg width='18' height='18'") + (on ? "Saved" : "Save"); else b.innerHTML = heart(on); }
const updSaved = () => $("#savedCount").textContent = Object.keys(saved).length;
const REG = new Map(); // id -> recipe object currently on screen
const reg = R => (REG.set(R.id, R), R);
document.addEventListener("click", e => {
  const s = e.target.closest("[data-save]"); if (s) { const R = REG.get(s.dataset.save) || saved[s.dataset.save]; if (R) toggleSave(R); return; }
  const o = e.target.closest("[data-open]"); if (o) { const R = REG.get(o.dataset.open) || saved[o.dataset.open]; if (R) openRecipe(R); }
});

/* ---------- Recipe card ---------- */
function recipeCard(R, i=0, opts={}){
  const n = nutrition(R.ings, R.serves).v;
  const top = R.ings.filter(x => x.k && ingPhoto(x.k)).slice(0,6);
  const badge = opts.badge ? `<span class="tag ${opts.badgeCls||""} badge">${esc(opts.badge)}</span>` : "";
  return `<article class="rcard ${opts.cls||""}" style="animation-delay:${(i%9)*60}ms">
    <div class="pic">${imgHTML(R.img)}${badge}<button class="save" data-save="${esc(R.id)}" aria-pressed="${isSaved(R.id)}" aria-label="Save recipe">${heart(isSaved(R.id))}</button></div>
    <div class="bd">
      ${R.sub ? `<span class="region">${esc(R.sub)}</span>` : ""}
      <h3>${esc(R.name)}</h3>
      ${R.desc ? `<p class="desc">${esc(R.desc)}</p>` : ""}
      ${opts.why ? `<p class="why">${esc(opts.why)}</p>` : ""}
      <div class="minis"><span>⏱ <b>${(+R.prep||0)+(+R.cook||0)} min</b></span><span>Protein <b>${fmtN(n[1],1)} g</b></span><span>Fibre <b>${fmtN(n[4],4)} g</b></span><span>Iron <b>${fmtN(n[5],5)} mg</b></span></div>
      ${top.length ? `<div class="thumbrow">${top.map(x => thumb(x.k, x.label, "th sm")).join("")}</div>` : ""}
      <div class="foot"><span class="kcal">≈ ${fmtN(n[0],0)} <small>kcal / serving</small></span><button class="btn btn-ghost btn-sm" data-open="${esc(R.id)}">View recipe</button></div>
    </div></article>`;
}

/* ---------- Drawer: full recipe view ---------- */
let drR = null, drTab = "overview";
const drawer = $("#drawer"), scrim = $("#scrim");
function openRecipe(R){
  drR = reg(R); drTab = "overview";
  drawer.classList.add("on"); scrim.classList.add("on"); drawer.setAttribute("aria-hidden","false"); document.body.classList.add("locked");
  renderDrawer();
  setTimeout(() => $(".dr-x", drawer)?.focus(), 50);
  if (R.kind === "care" && !R.steps?.length && !R.loading) loadCareDetail(R);
}
function closeDrawer(silent){ drawer.classList.remove("on"); scrim.classList.remove("on"); drawer.setAttribute("aria-hidden","true"); document.body.classList.remove("locked"); if (!silent) drR = null; }
scrim.onclick = () => closeDrawer();
document.addEventListener("keydown", e => { if (e.key === "Escape") { if (drawer.classList.contains("on")) closeDrawer(); else if (chat.classList.contains("open")) closeChat(); } });
function renderDrawer(){
  const R = drR; if (!R) return;
  const sub = R.kind === "fusion" ? R.region : R.kind === "care" ? CAT_LABEL[R.cat] : R.sub;
  $("#drHead").innerHTML = `${imgHTML(R.img)}<button class="dr-save" data-save="${esc(R.id)}"></button><button class="dr-x" aria-label="Close recipe">×</button>
    <div class="dr-title"><div class="sub">${esc(sub||"")}</div><h2>${esc(R.name)}</h2></div>`;
  paintSave($(".dr-save", drawer), isSaved(R.id));
  $(".dr-x", drawer).onclick = () => closeDrawer();
  const tabs = [["overview","Overview"],["nutrition","Nutrition"],["ingredients","Ingredients"],["prep","Preparation"],["cook","Cooking"]];
  if (R.kind === "care") tabs.push(["why","Why it suits you"]);
  tabs.push(["benefits","Benefits & alternatives"]);
  $("#drTabs").innerHTML = tabs.map(([k,l]) => `<button role="tab" aria-selected="${k===drTab}" data-t="${k}">${l}</button>`).join("");
  $("#drBody").innerHTML = TAB[drTab](R);
  $("#drBody").scrollTop = 0;
}
$("#drTabs").addEventListener("click", e => { const b = e.target.closest("[data-t]"); if (b) { drTab = b.dataset.t; renderDrawer(); } });
$("#drBody").addEventListener("click", e => { const b = e.target.closest("[data-goto]"); if (b) { drTab = b.dataset.goto; renderDrawer(); } });
const profileFor = R => R.kind === "care" ? careState.profile : null;
const pendingHTML = R => R.loading ? loadingHTML("Writing the full recipe for you…") : R.detailError ? `<div class="msg warn">${esc(R.detailError)}</div>` : "";
const TAB = {
  overview(R){
    const n = nutrition(R.ings, R.serves).v;
    let h = R.desc ? `<p style="font-size:1.05rem">${esc(R.desc)}</p>` : "";
    h += `<div class="facts"><div><span>Preparation</span><b>${esc(R.prep)} min</b></div><div><span>Cooking</span><b>${esc(R.cook)} min</b></div><div><span>Difficulty</span><b>${esc(R.diff||"Easy")}</b></div><div><span>${R.kind==="care"?"Portion":"Serves"}</span><b>${R.kind==="care"?"1 serving":esc(R.serves)}</b></div></div>`;
    if (R.fusion) {
      const f = R.fusion;
      h += `<div class="inspo"><div><img src="${R.img.a.src}" alt="${esc(R.img.a.label)}"><span class="eyebrow">Indian inspiration</span><p>${esc(f.inInspo)}</p></div><div><img src="${R.img.b.src}" alt="${esc(R.img.b.label)}"><span class="eyebrow">Emirati inspiration</span><p>${esc(f.aeInspo)}</p></div></div>
        <div class="blend"><h4>How the two cuisines combine</h4><p>${esc(f.how)}</p></div>
        <div class="blend" style="background:var(--sage)"><h4 style="color:var(--green-deep)">Why the flavours work together</h4><p>${esc(f.works)}</p></div>
        <p class="note">The photos show the two original dishes this recipe draws on. A new fusion dish has no photograph of its own yet.</p>`;
    }
    if (R.kind === "care" && R.why) h += `<div class="blend" style="background:var(--sage)"><h4 style="color:var(--green-deep)">Why it's on your list</h4><p>${esc(R.why)}</p><button class="btn btn-ghost btn-sm" data-goto="why" style="justify-self:start">See the full explanation</button></div>`;
    if (R.tip) h += `<div class="msg"><b>Tip:</b> ${esc(R.tip)}</div>`;
    h += `<div><h3 style="margin-bottom:10px">Per serving, approximately</h3><div class="facts">${[0,1,2,3].map(j => `<div><span>${NUT[j][0]}</span><b>${fmtN(n[j],j)} ${NUT[j][1]}</b></div>`).join("")}</div></div>`;
    return h;
  },
  nutrition(R){
    const { v, missing } = nutrition(R.ings, R.serves), p = profileFor(R), T = targets(p);
    const tiles = NUT.map(([l,u],j) => { const pct = T ? Math.round(v[j] / T[j] * 100) : null;
      return `<div class="nut"><span>${l}</span><b>${fmtN(v[j],j)} <small>${u}</small></b>${T ? `<div class="mini"><i style="width:${Math.min(100,pct)}%"></i></div><em>${pct}% of your daily target</em>` : ""}</div>`; }).join("");
    const e = [v[1]*4, v[2]*4, v[3]*9], tot = e.reduce((a,b)=>a+b,0) || 1, pc = e.map(x => Math.round(x/tot*100));
    return `<div><h3>Nutrition per serving</h3><p class="note">${R.kind==="care"?"One serving as listed.":`Whole recipe divided by ${R.serves} servings.`} Values are approximate.</p></div>
      <div class="nutgrid">${tiles}</div>
      <div class="stack" style="gap:10px"><b>Where the energy comes from</b>
        <div class="macro"><i style="width:${pc[0]}%;background:var(--green)"></i><i style="width:${pc[1]}%;background:var(--saffron)"></i><i style="width:${pc[2]}%;background:var(--clay)"></i></div>
        <div class="legend"><span><i style="background:var(--green)"></i>Protein ${pc[0]}%</span><span><i style="background:var(--saffron)"></i>Carbohydrate ${pc[1]}%</span><span><i style="background:var(--clay)"></i>Fat ${pc[2]}%</span></div></div>
      <p class="note">Approximate figures calculated in your browser from the ingredient weights in this recipe, using per-100 g reference values from USDA FoodData Central and the Indian Food Composition Tables (IFCT 2017).${T ? " Daily targets are estimated from your profile using ICMR-NIN 2020 reference intakes and the Mifflin–St Jeor equation." : ""}${missing.length ? ` Not counted (no reference value): ${esc(missing.join(", "))}.` : ""} Salt and water are not counted.</p>`;
  },
  ingredients(R){
    return `<div><h3>Ingredients</h3><p class="note">${R.kind==="care"?"Quantities for one serving.":`Quantities for ${esc(R.serves)} servings.`}</p></div>
      <div class="ilist">${R.ings.map(i => `<div>${thumb(i.k, i.label, "th lg")}<span><b>${esc(i.label)}</b>${i.k && i.label.toLowerCase().indexOf(ingName(i.k).toLowerCase()) < 0 ? `<br><span class="note">${esc(ingName(i.k))}</span>` : ""}</span><span class="g">${i.g ? `${fmtN(i.g, i.g<10?1:0)} g` : ""}</span></div>`).join("")}</div>`;
  },
  prep(R){ return R.prepSteps?.length ? `<h3>Preparation</h3><ol class="steps">${R.prepSteps.map(s => `<li><span>${esc(s)}</span></li>`).join("")}</ol>` : pendingHTML(R) || `<p class="muted">No special preparation needed.</p>`; },
  cook(R){ return R.steps?.length ? `<h3>Cooking instructions</h3><ol class="steps">${R.steps.map(s => `<li><span>${esc(s)}</span></li>`).join("")}</ol>` : pendingHTML(R); },
  why(R){
    const p = careState.profile, W = whyFor(R, p), ai = R.aiWhy || {};
    const sec = (title, items, extra) => `<div><h4>${title}</h4><ul>${items.map(x => `<li>${esc(x)}</li>`).join("")}${extra ? `<li>${esc(extra)}</li>` : ""}</ul></div>`;
    return `<div><h3>Why this meal is suitable for you</h3><p class="note">Checked against the profile ${p?.example ? "in the example plan" : "you entered"}. Figures are per serving.</p></div>
      ${R.why ? `<div class="msg">${esc(R.why)}</div>` : ""}
      <div class="whyb">${sec("Your nutritional needs", W.needs, ai.needs)}${sec("Your dietary preferences", W.prefs, ai.preferences)}${sec("Nutrients it provides", W.nutrients, ai.nutrients)}${sec("Your food restrictions", W.restr, ai.restrictions)}${ai.benefits ? sec("Potential benefits", [], ai.benefits) : ""}</div>
      ${R.review ? `<div class="review"><span>⚕</span><div><b>Ask a professional</b>${esc(R.review)}</div></div>` : ""}
      ${pendingHTML(R)}
      <p class="note">No single meal treats, cures or prevents a medical condition. This is general guidance; follow your doctor's or dietitian's advice.</p>`;
  },
  benefits(R){
    const n = nutrition(R.ings, R.serves).v, p = profileFor(R);
    const B = benefitsFor(n); (R.aiBenefits||[]).forEach(b => B.push([b.nutrient, b.text]));
    const swaps = swapsFor(R, p);
    return `<div><h3>Nutritional benefits</h3><p class="note">What the main nutrients in one serving do, in plain words.</p></div>
      <div class="whyb">${B.map(([t,x]) => `<div><h4>${esc(t)}</h4><p>${esc(x)}</p></div>`).join("")}</div>
      <div><h3>Alternative ingredients</h3><p class="note">Swaps for things you can't eat, don't have, or want to make healthier. Changes are per serving.</p></div>
      <div class="stack" style="gap:10px">${swaps.map(s => `<div class="swap">${thumb(s.from, ingName(s.from))}<span class="arrow">→</span>${thumb(s.to, ingName(s.to))}<div class="txt"><b>${esc(ingName(s.from))} → ${esc(ingName(s.to))}</b><span class="muted">${esc(s.note)}</span><div class="delta">${s.delta}</div></div></div>`).join("") || ""}
      ${(R.altText||[]).map(t => `<div class="msg">${esc(t)}</div>`).join("")}
      ${(R.aiAlts||[]).map(a => `<div class="msg"><b>${esc(a.from)} → ${esc(a.to)}</b><br>${esc(a.effect)}</div>`).join("")}
      ${!swaps.length && !(R.altText||[]).length && !(R.aiAlts||[]).length ? `<p class="muted">${R.loading ? "Loading alternatives…" : "This recipe already uses simple, everyday ingredients."}</p>` : ""}</div>
      ${pendingHTML(R)}`;
  },
};
function benefitsFor(n){
  const B = [];
  if (n[1] >= 12) B.push([`Protein · ${fmtN(n[1],1)} g`, "Helps build and keep muscle, which matters more as we get older, and keeps you full for longer."]);
  if (n[4] >= 5) B.push([`Fibre · ${fmtN(n[4],4)} g`, "Slows down how quickly sugar reaches the blood, keeps digestion regular and helps manage cholesterol."]);
  if (n[5] >= 3) B.push([`Iron · ${fmtN(n[5],5)} mg`, "Your body uses iron to make haemoglobin, which carries oxygen in the blood. Iron from plants is absorbed better with vitamin C (lemon, tomato, guava)."]);
  if (n[6] >= 150) B.push([`Calcium · ${fmtN(n[6],6)} mg`, "Keeps bones and teeth strong and helps muscles and nerves work."]);
  if (n[7] >= .4) B.push([`Vitamin B12 · ${fmtN(n[7],7)} µg`, "Needed for healthy nerves and red blood cells. It's found almost only in animal foods, so dairy and eggs matter for vegetarians."]);
  if (n[0] <= 380) B.push([`Light · ${fmtN(n[0],0)} kcal`, "A moderate amount of energy that fits easily into a day of meals."]);
  if (n[3] <= 10 && n[0] > 0) B.push([`Low in fat · ${fmtN(n[3],3)} g`, "Little fat overall, which helps if you are watching calories or cholesterol."]);
  if (!B.length) B.push(["Balanced meal", "Provides a mix of energy, protein and fibre without large amounts of any one nutrient."]);
  return B;
}
function swapsFor(R, p){
  const factor = { "chicken>chickpeas":.5, "cooked_rice>quinoa":.33, "khoya>milk":4 };
  const keys = new Set(R.ings.map(i => i.k)), out = [];
  for (const i of R.ings) {
    const s = D.SWAPS[i.k]; if (!s || out.some(o => o.from === i.k)) continue;
    const [to, note] = s; if (keys.has(to) || keyConflicts(to, p)) continue;
    const f = factor[`${i.k}>${to}`] || 1;
    const after = R.ings.map(x => x.k === i.k ? { ...x, k:to, g:x.g*f } : x);
    const a = nutrition(R.ings, R.serves).v, b = nutrition(after, R.serves).v;
    const d = [[0,"kcal",5],[1,"g protein",.5],[3,"g fat",.5],[4,"g fibre",.5],[5,"mg iron",.3],[6,"mg calcium",10],[7,"µg B12",.1]]
      .map(([j,u,min]) => { const x = b[j]-a[j]; if (Math.abs(x) < min) return ""; const good = j===0||j===3 ? x<0 : x>0; return `<span class="${good?"up":"dn"}">${x>0?"+":"−"}${fmtN(Math.abs(x),j)} ${u}</span>`; }).join("");
    out.push({ from:i.k, to, note, delta: d || `<span>About the same nutritionally</span>` });
  }
  return out;
}
function whyFor(R, p){
  const n = nutrition(R.ings, R.serves).v, T = targets(p) || [1,1,1,1,1,1,1,1], pct = j => Math.round(n[j]/T[j]*100);
  const has = ks => R.ings.filter(i => ks.includes(i.k)).map(i => ingName(i.k).toLowerCase());
  const needs = [], c = p?.conditions||[], g = p?.goals||[];
  if (c.some(x => /diabetes/i.test(x)) || g.includes("Less sugar")) { const sw = has(["sugar","jaggery","honey","date_syrup"]); needs.push(`About ${fmtN(n[2],2)} g carbohydrate with ${fmtN(n[4],4)} g fibre to slow its absorption${sw.length ? `. Contains a little ${sw.join(", ")}` : ", and no added sugar"}.`); }
  if (c.includes("Anaemia / low iron") || g.includes("More iron") || c.includes("Pregnancy")) { const vc = has(["lemon","tomato","guava","bell_pepper","orange","pomegranate","papaya","green_chilli","mango"]); needs.push(`${fmtN(n[5],5)} mg iron, ${pct(5)}% of your daily target.${vc.length ? ` The ${[...new Set(vc)].slice(0,3).join(", ")} add vitamin C, which helps your body absorb iron from plant foods.` : ""}`); }
  if (g.includes("More protein") || g.includes("Gain weight / muscle") || (+p?.age >= 60)) needs.push(`${fmtN(n[1],1)} g protein (${pct(1)}% of your daily target), which helps maintain muscle${+p?.age >= 60 ? " as you age" : ""}.`);
  if (g.includes("More fibre")) needs.push(`${fmtN(n[4],4)} g fibre, ${pct(4)}% of your daily target.`);
  if (g.includes("More calcium") || c.includes("Osteoporosis / low bone density")) needs.push(`${fmtN(n[6],6)} mg calcium, ${pct(6)}% of your daily target.`);
  if (g.includes("More vitamin B12") || ["Vegetarian","Vegan"].includes(p?.diet)) needs.push(n[7] >= .2 ? `${fmtN(n[7],7)} µg vitamin B12 from ${has(["milk","yoghurt","paneer","egg","labneh","cheese","fish","soy_milk"]).join(", ") || "its ingredients"}.` : "Little vitamin B12, so pair your day with dairy, eggs or a fortified food.");
  if (c.includes("High blood pressure") || g.includes("Less salt")) needs.push("Flavoured with spices, herbs and sourness, so it needs little added salt. Skip pickles and papad on the side.");
  if (c.includes("High cholesterol") || c.includes("Heart disease") || g.includes("Less fat")) { const sat = has(["ghee","butter","cream","coconut_milk","coconut_oil","khoya"]); needs.push(`${fmtN(n[3],3)} g fat per serving${sat.length ? `, partly saturated from ${sat.join(", ")}; see the swaps tab for lighter options` : ", mostly from unsaturated sources"}.`); }
  if (g.includes("Lose weight")) needs.push(`${fmtN(n[0],0)} kcal, about ${pct(0)}% of your reduced daily energy target.`);
  if (!needs.length) needs.push(`${fmtN(n[0],0)} kcal with ${fmtN(n[1],1)} g protein and ${fmtN(n[4],4)} g fibre, a balanced share of your day.`);
  const prefs = [];
  if (p?.diet) prefs.push(`Fits your ${p.diet.toLowerCase()} diet. All ${R.ings.length} ingredients were checked.`);
  (p?.reqs||[]).forEach(r => prefs.push(`Meets your requirement: ${r.toLowerCase()}.`));
  const dc = D.DISH[R.photo]; if (dc && p?.cuisines?.length) prefs.push(`Based on ${dc[0]} (${dc[2]}). You chose ${p.cuisines.join(", ")}.`);
  const order = [1,4,5,6,7].map(j => [j, n[j]/T[j]]).sort((a,b) => b[1]-a[1]).slice(0,3);
  const nutrients = [`Best contributions to your day: ${order.map(([j,r]) => `${NUT[j][0].toLowerCase()} ${Math.round(r*100)}%`).join(", ")}.`, `${fmtN(n[0],0)} kcal, ${fmtN(n[2],2)} g carbohydrate and ${fmtN(n[3],3)} g fat per serving.`];
  const restr = [];
  const al = [...(p?.allergies||[]), ...(p?.allergyOther ? [p.allergyOther] : [])];
  restr.push(al.length ? `Contains none of your declared allergens (${al.join(", ")}). Every ingredient was checked by type and by name.` : "You didn't list any allergies.");
  if (p?.avoid) restr.push(`Leaves out the foods you asked to avoid: ${p.avoid}.`);
  if (p?.pro) restr.push(`Your professional's instructions were included when choosing this meal: "${p.pro}"`);
  const conf = conflictsOf(R, p); if (conf.length) restr.push(`Warning: ${conf.join("; ")}. Don't eat this until it's adjusted.`);
  return { needs, prefs, nutrients, restr };
}

/* ---------- Smart Recipes ---------- */
const UNITS = ["pcs","g","kg","cup","tbsp","tsp","ml","bunch"];
let myIngs = store.get("myIngs", null) || [["cooked_rice","2","cup"],["tomato","3","pcs"],["onion","1","pcs"],["paneer","200","g"],["coriander","1","bunch"],["yoghurt","1","cup"]].map(([k,q,u]) => ({ id:uid("m"), k, name:ingName(k), qty:q, unit:u }));
const saveIngs = () => store.set("myIngs", myIngs);
function defaultQty(k){ const u = D.ING[k]?.[3] || {}; return u.pcs ? ["1","pcs"] : u.bunch ? ["1","bunch"] : u.cup ? ["1","cup"] : ["100","g"]; }
function addMyIng(k, name){
  if (k && myIngs.some(i => i.k === k)) return false;
  const [q,u] = defaultQty(k); myIngs.push({ id:uid("m"), k, name: k ? ingName(k) : name, qty:q, unit:u }); saveIngs(); renderMyIngs(); renderPantry(); return true;
}
function renderMyIngs(){
  $("#ingCount").textContent = myIngs.length ? `· ${myIngs.length}` : "";
  $("#ingRows").innerHTML = myIngs.length ? myIngs.map(i => `<div class="ing-row" data-id="${i.id}">${thumb(i.k, i.name)}<span class="nm" title="${esc(i.name)}">${esc(i.name)}</span>
    <input class="field" id="q-${i.id}" value="${esc(i.qty)}" inputmode="decimal" aria-label="Quantity of ${esc(i.name)}">
    <select class="field" id="u-${i.id}" aria-label="Unit">${UNITS.map(x => `<option${x===i.unit?" selected":""}>${x}</option>`).join("")}</select>
    <button type="button" class="x" aria-label="Remove ${esc(i.name)}">×</button></div>`).join("")
    : `<div class="msg">No ingredients yet. Tap items in the pantry or type one below.</div>`;
}
$("#ingRows").addEventListener("input", e => { const r = e.target.closest(".ing-row"); if (!r) return; const i = myIngs.find(x => x.id === r.dataset.id); if (e.target.tagName === "SELECT") i.unit = e.target.value; else i.qty = e.target.value; saveIngs(); });
$("#ingRows").addEventListener("change", e => { const r = e.target.closest(".ing-row"); if (r && e.target.tagName === "SELECT") { myIngs.find(x => x.id === r.dataset.id).unit = e.target.value; saveIngs(); } });
$("#ingRows").addEventListener("click", e => { const b = e.target.closest(".x"); if (!b) return; myIngs = myIngs.filter(x => x.id !== b.closest(".ing-row").dataset.id); saveIngs(); renderMyIngs(); renderPantry(); });
$("#clearIngs").onclick = () => { myIngs = []; saveIngs(); renderMyIngs(); renderPantry(); };
$("#ingList").innerHTML = Object.entries(D.ING).filter(([k]) => !["salt","water","yeast"].includes(k)).map(([,v]) => `<option value="${esc(v[0])}">`).join("");
function addTyped(){ const v = $("#ingAdd").value.trim(); if (!v) return; const k = matchKey(v); if (!addMyIng(k, v)) $("#scanMsg").textContent = ""; $("#ingAdd").value = ""; }
$("#ingAddBtn").onclick = addTyped;
$("#ingAdd").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); addTyped(); } });
let pTab = "veg";
function renderPantry(){
  $("#pantryTabs").innerHTML = D.ING_CATS.map(([k,l]) => `<button role="tab" aria-selected="${k===pTab}" data-c="${k}">${l}</button>`).join("");
  const q = norm($("#pantrySearch").value);
  const list = Object.entries(D.ING).filter(([k,v]) => D.PHOTO_I.has(k) && (q ? (norm(v[0]).includes(q) || norm(v[4]).includes(q)) : v[1] === pTab));
  $("#pantry").innerHTML = list.map(([k,v]) => `<button type="button" class="tile" data-k="${k}" aria-pressed="${myIngs.some(i => i.k === k)}"><img src="${ingPhoto(k)}" alt="" loading="lazy">${esc(v[0])}</button>`).join("") || `<p class="note">No matching ingredients. Type it in on the left instead.</p>`;
}
$("#pantryTabs").addEventListener("click", e => { const b = e.target.closest("[data-c]"); if (b) { pTab = b.dataset.c; $("#pantrySearch").value = ""; renderPantry(); } });
$("#pantrySearch").addEventListener("input", renderPantry);
$("#pantry").addEventListener("click", e => { const t = e.target.closest(".tile"); if (!t) return; const k = t.dataset.k;
  if (myIngs.some(i => i.k === k)) { myIngs = myIngs.filter(i => i.k !== k); saveIngs(); renderMyIngs(); renderPantry(); } else addMyIng(k); });
const DIETS = ["Vegetarian","Vegan","Jain","Eggetarian","Halal","Gluten-free","Dairy-free","Low sugar","High protein"];
$("#dietChips").innerHTML = DIETS.map(d => `<button type="button" class="chip" aria-pressed="${d==="Vegetarian"}">${d}</button>`).join("");
$("#dietChips").addEventListener("click", e => { const c = e.target.closest(".chip"); if (c) c.setAttribute("aria-pressed", c.getAttribute("aria-pressed") !== "true"); });

let ingPhotos = [];
function wireDrop(drop, input, onFiles){
  input.addEventListener("change", () => onFiles([...input.files]));
  ["dragenter","dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave","drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", e => onFiles([...e.dataTransfer.files].filter(f => f.type.startsWith("image/"))));
}
wireDrop($("#ingDrop"), $("#ingFile"), files => {
  ingPhotos = files.slice(0,4);
  $("#ingThumbs").innerHTML = ingPhotos.map(f => `<img src="${URL.createObjectURL(f)}" alt="">`).join("");
  $("#scanMsg").textContent = cap.images ? "" : (ingPhotos.length ? "Photo scanning needs the page open on claude.ai. Add items from the pantry for now." : "");
  refreshAvailability();
});
$("#scanBtn").onclick = async () => {
  const b = $("#scanBtn"); b.disabled = true; $("#scanMsg").innerHTML = loadingHTML("Looking for ingredients…");
  try {
    const out = await askJSON(`These photos show food ingredients in a home kitchen. List each distinct ingredient you can identify with an estimated quantity. Use a key from this list when it matches, else null: ${ING_KEYS}.
Return JSON: {"items":[{"k":key|null,"name":short English name,"qty":string,"unit":one of ${JSON.stringify(UNITS)}}]}`, { images: ingPhotos, modelTier:"quick" });
    let added = 0;
    (out?.items||[]).forEach(i => { const k = i.k && D.ING[i.k] ? i.k : matchKey(i.name); if (k && myIngs.some(x => x.k === k)) return;
      myIngs.push({ id:uid("m"), k, name: k ? ingName(k) : i.name, qty: String(i.qty||1), unit: UNITS.includes(i.unit) ? i.unit : "pcs" }); added++; });
    saveIngs(); renderMyIngs(); renderPantry();
    $("#scanMsg").textContent = added ? `Added ${added} ingredient${added>1?"s":""} from your photos. Check the quantities.` : "No new ingredients were recognised. Try a closer, brighter photo.";
  } catch(e){ $("#scanMsg").textContent = errMsg(e); }
  b.disabled = false;
};
function fromSmart(r, i){
  const ings = typeof r.ings === "string" ? parseIngs(r.ings) : aiIngs(r.ings);
  return { id: r.id || uid("s"), kind:"smart", name:r.name, sub:r.cuisine, desc:r.desc, photo:r.photo, img:imgFor(r.photo, ings, r.name), serves:+r.serves||2,
    prep:+r.prep||10, cook:+r.cook||20, diff:r.diff||r.difficulty||"Easy", ings, prepSteps:r.prepSteps||[], steps:r.steps||[], tip:r.tip, aiAlts:r.alts };
}
function renderRecipes(list, title, note){
  $("#recTitle").textContent = title; $("#recNote").textContent = note;
  $("#recipeCards").innerHTML = list.map((R,i) => recipeCard(reg(R), i)).join("");
}
$("#recipeForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!myIngs.length) { $("#recNote").textContent = "Add at least one ingredient to get recipes."; return; }
  const diet = $$("#dietChips .chip[aria-pressed='true']").map(c => c.textContent);
  const btn = $("#genBtn"); btn.disabled = true; btn.textContent = "Cooking up ideas…";
  $("#recipeCards").innerHTML = `<div style="grid-column:1/-1">${loadingHTML("Matching your ingredients to recipes…")}</div>`;
  $("#recTitle").scrollIntoView({ behavior:"smooth", block:"start" });
  try {
    const res = await askJSON(`You are REPLATE, a food-waste-reducing recipe assistant for Indian, Emirati and Arabian home cooking. Do NOT invent fusion dishes here; suggest traditional home dishes.
Ingredients on hand: ${myIngs.map(i => `${i.name} ${i.qty} ${i.unit}`).join("; ")}.
Dietary needs (strict): ${diet.join(", ") || "none"}. Cuisine: ${$("#cuisinePref").value}. Time: ${$("#timePref").value}. Servings: ${$("#servings").value}.
Suggest 3 different recipes that use as many listed ingredients as possible, prioritising perishables. Assume basic spices, salt and oil are available.
PHOTO: set "photo" to the key of the dish in this library that the recipe IS (same dish, so the photo is accurate), or null if none matches: ${dishLibrary(null)}.
INGREDIENTS: list every ingredient for the whole recipe with grams. Use a key from this list when it matches, else null: ${ING_KEYS}.
Write text in ${replyLang()}.
Return JSON: {"recipes":[{"name":string,"cuisine":string,"desc":one sentence,"photo":key|null,"serves":number,"prep":minutes,"cook":minutes,"difficulty":"Easy"|"Medium"|"Hard","ings":[{"k":key|null,"name":string,"qty":household measure,"g":grams}],"prepSteps":[1-3 steps],"steps":[4-6 steps],"tip":leftover or storage tip,"alts":[{"from":string,"to":string,"effect":string}]}]}`);
    const recs = (res?.recipes||[]).slice(0,3).map(fromSmart);
    if (!recs.length) throw { code:"empty" };
    renderRecipes(recs, "Recipes for your kitchen", `Built from ${myIngs.length} ingredients${diet.length ? " · " + diet.join(", ") : ""}. Tap a recipe for nutrition and full steps.`);
  } catch(err){ renderRecipes(D.LOCAL_RECIPES.map((r,i) => fromSmart({ ...r, id:"local"+i })), "Recipe ideas", errMsg(err) + " Showing built-in recipes instead."); }
  btn.disabled = false; btn.textContent = "Generate recipes";
});

/* ---------- Fusion ---------- */
const SHARED = ["saffron","cardamom","dates","ghee","rose_water","dried_lime","cinnamon","basmati_rice","garam_masala","tamarind","pistachio","yoghurt"];
$("#sharedPantry").innerHTML = SHARED.map(k => `<span class="it"><img src="${ingPhoto(k)}" alt="">${esc(ingName(k))}</span>`).join("");
const pSrc = ([t,k]) => `img/${t}/${k}.jpg`;
function fromFusion(f){
  const ings = typeof f.ings === "string" ? parseIngs(f.ings) : aiIngs(f.ings);
  return { id:f.id, kind:"fusion", name:f.name, sub:f.region, region:f.region, desc:f.tagline || f.how, type:f.type, healthy:f.healthy, serves:+f.serves||4, prep:+f.prep||15, cook:+f.cook||30, diff:f.diff||f.difficulty||"Medium",
    img:{ type:"split", a:{ src:pSrc(f.photos[0]), label:f.photos[0][2] }, b:{ src:pSrc(f.photos[1]), label:f.photos[1][2] } },
    fusion:{ inInspo:f.inInspo, aeInspo:f.aeInspo, how:f.how, works:f.works }, ings, prepSteps:f.prepSteps||[], steps:f.steps||[],
    alts:f.alts, altText:f.altText||[], aiAlts:f.aiAlts||[] };
}
const FZ = D.FUSION.map(fromFusion);
let fzFilter = "all";
$("#fzFilters").innerHTML = [["all","All"],["savoury","Savoury"],["sweet","Sweet"],["healthy","Healthy"]].map(([k,l]) => `<button class="chip" data-f="${k}" aria-pressed="${k===fzFilter}">${l}</button>`).join("");
$("#fzFilters").addEventListener("click", e => { const b = e.target.closest("[data-f]"); if (!b) return; fzFilter = b.dataset.f; $$("#fzFilters .chip").forEach(c => c.setAttribute("aria-pressed", c === b)); renderFz(); });
function renderFz(){
  const list = FZ.filter(R => fzFilter === "all" || (fzFilter === "healthy" ? R.healthy : R.type === fzFilter));
  $("#fzCards").innerHTML = list.map((R,i) => recipeCard(reg(R), i, { badge: R.type === "sweet" ? "Sweet" : R.healthy ? "Healthy" : "Savoury", badgeCls: R.healthy ? "green" : "saf" })).join("");
}
let leftovers = store.get("leftovers", ["cooked_rice","dates","yoghurt"].map(k => ({ k, name:ingName(k) })));
function renderLeftovers(){
  $("#loList").innerHTML = leftovers.length ? leftovers.map((l,i) => `<span class="lo">${thumb(l.k, l.name)}${esc(l.name)}<button type="button" data-i="${i}" aria-label="Remove ${esc(l.name)}">×</button></span>`).join("") : `<span class="note">Nothing added yet. Leave it empty and REPLATE will pick a pairing for you.</span>`;
  $("#loPantry").innerHTML = SHARED.concat(["cooked_rice","paneer","chicken","chickpeas","carrot","vermicelli","egg","fish","lamb","coconut","oats","khubz"]).filter((k,i,a) => a.indexOf(k) === i)
    .map(k => `<button type="button" class="tile" data-k="${k}" aria-pressed="${leftovers.some(l => l.k === k)}"><img src="${ingPhoto(k)}" alt="" loading="lazy">${esc(ingName(k))}</button>`).join("");
  store.set("leftovers", leftovers);
}
$("#loList").addEventListener("click", e => { const b = e.target.closest("[data-i]"); if (b) { leftovers.splice(+b.dataset.i,1); renderLeftovers(); } });
$("#loPantry").addEventListener("click", e => { const t = e.target.closest(".tile"); if (!t) return; const k = t.dataset.k;
  if (leftovers.some(l => l.k === k)) leftovers = leftovers.filter(l => l.k !== k); else leftovers.push({ k, name:ingName(k) }); renderLeftovers(); });
function addLo(){ const v = $("#loAdd").value.trim(); if (!v) return; const k = matchKey(v); if (!(k && leftovers.some(l => l.k === k))) leftovers.push({ k, name: k ? ingName(k) : v }); $("#loAdd").value = ""; renderLeftovers(); }
$("#loAddBtn").onclick = addLo; $("#loAdd").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); addLo(); } });
let fzMine = store.get("fzMine", []);
function renderFzMine(){ $("#fzMineHead").hidden = !fzMine.length; $("#fzMine").innerHTML = fzMine.map((R,i) => recipeCard(reg(R), i, { badge:"AI creation", badgeCls:"saf" })).join(""); }
const IN_LIB = dishLibrary(null, c => c === "in"), AE_LIB = dishLibrary(null, c => c !== "in");
async function generateFusion(useLeftovers){
  const go = $("#fzGo"), sp = $("#fzSurprise"); go.disabled = sp.disabled = true; $("#fzMsg").innerHTML = loadingHTML("Pairing the two kitchens…");
  const lo = useLeftovers ? leftovers.map(l => l.name) : [];
  const healthy = $("#fzHealthy").checked;
  try {
    const r = await askJSON(`You are REPLATE's Indian × Emirati fusion chef. Create ONE original fusion dish that genuinely combines a specific Indian dish or technique with authentic Emirati cuisine.
RULES (most important first):
1. Culinary compatibility and authenticity matter more than novelty. Only combine elements that share flavours, ingredients or techniques (e.g. cardamom, saffron, rose water, dates, ghee, rice cooked in broth, slow-cooked wheat, sour notes from loomi vs tamarind/kokum, bzar vs garam masala). Never just place two unrelated dishes side by side.
2. The Emirati side must be genuinely Emirati (machboos, harees, thareed, saloona, balaleet, luqaimat, chebab, khameer, regag, khabeesa, madrooba, jasheed, bzar, loomi, dibs) — not generic Levantine food.
3. Must be realistically cookable at home in India or the UAE with affordable, common ingredients. Practical methods only.
4. ${healthy ? "Make it a healthy, nutritionally balanced version (less ghee/sugar, more vegetables, pulses, whole grains)." : "Keep it balanced; don't overdo ghee or sugar."}
5. ${lo.length ? `Build it around these leftovers/ingredients: ${lo.join(", ")}. Use as many as make sense; if they cannot make a sensible Indian–Emirati dish, set "feasible": false, explain why in "reason", and still give the closest sensible fusion dish using what you can.` : "Choose a pairing that is not one of these existing REPLATE recipes: " + FZ.map(f => f.name).join(", ") + "."}
Preferences: course ${$("#fzCourse").value}; ${$("#fzStyle").value}; Indian side ${$("#fzIn").value}; Emirati side ${$("#fzAe").value}; diet ${$("#fzDiet").value} (strict); serves ${$("#fzServes").value}.
PHOTOS: "inPhoto" must be the key of the real Indian parent dish from: ${IN_LIB}. "aePhoto" must be the closest real Emirati/Arabian parent dish from: ${AE_LIB}. Labels name exactly what each photo shows.
INGREDIENTS for the whole recipe with grams; use a key from this list when it matches, else null: ${ING_KEYS}.
Write all text in ${replyLang()}.
Return JSON: {"feasible":boolean,"reason":string|null,"name":string,"tagline":one sentence,"type":"sweet"|"savoury","healthy":boolean,"region":"<Indian region> × Emirati","inPhoto":key,"inLabel":string,"aePhoto":key,"aeLabel":string,"inInspo":2 sentences,"aeInspo":2 sentences,"how":2-3 sentences,"works":2-3 sentences on why the flavours, textures and techniques are compatible,"serves":number,"prep":minutes,"cook":minutes,"difficulty":"Easy"|"Medium"|"Hard","ings":[{"k":key|null,"name":string,"qty":string,"g":number}],"prepSteps":[2-4],"steps":[5-8 clear steps],"alts":[{"from":string,"to":string,"effect":"healthier swap and how taste/nutrition change"}]}`, { modelTier:"default" });
    if (!r?.name) throw { code:"empty" };
    const inK = D.DISH[r.inPhoto] ? r.inPhoto : "biryani", aeK = D.DISH[r.aePhoto] ? r.aePhoto : "machboos";
    const R = fromFusion({ ...r, id:uid("fz"), photos:[["d",inK,r.inLabel||D.DISH[inK][0]],["d",aeK,r.aeLabel||D.DISH[aeK][0]]], aiAlts:r.alts, alts:[] });
    fzMine.unshift(R); fzMine = fzMine.slice(0,12); store.set("fzMine", fzMine); renderFzMine();
    $("#fzMsg").innerHTML = r.feasible === false ? `<div class="msg warn"><b>Those leftovers don't make a natural fusion.</b> ${esc(r.reason||"")} Here's the closest dish that works.</div>` : `Created <b>${esc(R.name)}</b>.`;
    openRecipe(R);
  } catch(e){ $("#fzMsg").innerHTML = `<div class="msg">${esc(errMsg(e))} Try one of the signature recipes above in the meantime.</div>`; }
  go.disabled = sp.disabled = false;
}
$("#fzGo").onclick = () => generateFusion(true);
$("#fzSurprise").onclick = () => generateFusion(false);

/* ---------- Quality checker ---------- */
let qPhoto = null;
wireDrop($("#qDrop"), $("#qFile"), files => {
  qPhoto = files[0] || null; if (!qPhoto) return;
  const img = $("#qPreview"); img.src = URL.createObjectURL(qPhoto); img.hidden = false;
  $("#qBtn").disabled = false; $("#qMsg").textContent = cap.images ? "" : "Photo analysis needs the page open on claude.ai with Claude access allowed.";
});
const VERD = { fresh:["fresh","Fresh · safe to eat"], soon:["soon","Use within a day"], discard:["discard","Discard · not safe"] };
function gauge(score, cls){
  const c = 2*Math.PI*48, v = Math.max(0,Math.min(100,+score||0)), col = cls==="fresh"?"var(--ok)":cls==="soon"?"var(--warn)":"var(--bad)";
  return `<svg class="gauge" viewBox="0 0 120 120"><circle cx="60" cy="60" r="48" fill="none" stroke="var(--line)" stroke-width="12"/><circle cx="60" cy="60" r="48" fill="none" stroke="${col}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${(c*v/100).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 60 60)"/><text x="60" y="58" text-anchor="middle" font-size="28" font-weight="700" fill="var(--ink)">${v}</text><text x="60" y="78" text-anchor="middle" font-size="11" fill="var(--muted)">freshness</text></svg>`;
}
function renderQuality(q, src, example){
  const [cls,label] = VERD[q.verdict] || VERD.soon;
  $("#qResult").innerHTML = `${example?`<p class="example-flag" style="margin-bottom:12px">Example result · upload a photo for yours</p>`:""}
    <div class="verdict">${src?`<img class="q-photo" src="${src}" alt="">`:""}${gauge(q.score, cls)}<div style="display:grid;gap:8px;min-width:0;flex:1"><h2 style="font-size:1.55rem">${esc(q.item)}</h2><span><span class="pill ${cls}">${label}</span></span><p class="muted">${esc(q.summary)}</p></div></div>
    <div class="signs">${(q.signs||[]).map(s=>`<div><b>${esc(s.label)}</b>${esc(s.value)}</div>`).join("")}</div>
    <div class="signs"><div><b>What to do</b>${esc(q.advice)}</div><div><b>How to store</b>${esc(q.storage)}</div></div>`;
}
renderQuality({ item:"Bananas, 5 days old", verdict:"soon", score:58, summary:"Peel is heavily speckled with brown sugar spots. No mould, splits or leaking. The flesh is likely soft and very sweet.",
  signs:[{label:"Colour",value:"Yellow with dense brown speckling"},{label:"Surface",value:"Intact peel, no mould"},{label:"Texture",value:"Likely soft; stem end slightly dry"},{label:"Smell to check",value:"Sweet is fine; fermented or sour means discard"}],
  advice:"Bake into banana bread, blend into a lassi, or slice and freeze for smoothies today.", storage:"Keep away from other fruit. Peel and freeze in a bag if you can't use them within a day." }, "img/i/banana.jpg", true);
$("#qBtn").onclick = async () => {
  if (!qPhoto) return; const b = $("#qBtn"); b.disabled = true; $("#qResult").innerHTML = loadingHTML("Checking colour, surface and texture…");
  try {
    if (!cap.images) throw { code:"unavailable" };
    const q = await askJSON(`You are a food safety assistant. Examine the food in this photo and judge its freshness for home use. Be cautious: mould on soft foods, slime or signs of spoilage mean discard. Write text in ${replyLang()}.
Return JSON: {"item":string,"verdict":"fresh"|"soon"|"discard","score":0-100,"summary":1-2 sentences,"signs":[{"label":"Colour"|"Surface"|"Texture"|"Smell to check","value":string}],"advice":string,"storage":string}`, { images:[qPhoto] });
    renderQuality(q, $("#qPreview").src, false);
  } catch(e){ $("#qResult").innerHTML = `<p class="muted">${esc(errMsg(e))}</p>`; }
  b.disabled = false;
};

/* ---------- REPLATE CARE ---------- */
const CAT_LABEL = { breakfast:"Breakfast", lunch:"Lunch", dinner:"Dinner", snacks:"Healthy snack", dessert:"Dessert" };
const CAT_PLAN = [["breakfast",7],["lunch",7],["dinner",6],["snacks",3],["dessert",2]];
const OPTS = {
  conditions:["Type 2 diabetes","Prediabetes","Type 1 diabetes","High blood pressure","High cholesterol","Heart disease","Chronic kidney disease","Anaemia / low iron","PCOS","Hypothyroidism","Osteoporosis / low bone density","IBS / sensitive digestion","Coeliac disease","Lactose intolerance","Gout","Fatty liver","Pregnancy","Breastfeeding","Swallowing difficulty","Recovering from illness"],
  allergies:Object.keys(ALLERGY),
  goals:["More protein","More fibre","More iron","More calcium","More vitamin B12","Less sugar","Less salt","Less fat","Lose weight","Gain weight / muscle"],
  reqs:["Halal","Gluten-free","Dairy-free","No onion or garlic","Soft, easy-to-chew foods"],
  cuisines:["North Indian","South Indian","Bengali","Gujarati","Maharashtrian","Emirati / Arabian","Levantine"],
  diet:["Vegetarian","Eggetarian","Vegan","Non-vegetarian","Jain"],
};
const REVIEW_COND = ["Type 1 diabetes","Chronic kidney disease","Pregnancy","Breastfeeding","Coeliac disease","Swallowing difficulty","Heart disease","Fatty liver","Recovering from illness"];
function fromCare(m){
  const ings = typeof m.ings === "string" ? parseIngs(m.ings) : (m.ings[0]?.label !== undefined ? m.ings : aiIngs(m.ings));
  return { id:m.id, kind:"care", cat:m.cat, name:m.name, desc:m.desc, why:m.why, photo:m.photo, img:imgFor(m.photo, ings, m.name), serves:1,
    prep:+m.prep||10, cook:+m.cook||15, diff:m.diff||m.difficulty||"Easy", ings, prepSteps:m.prepSteps||[], steps:m.steps||[], example:!!m.example };
}
let careState = store.get("care", null);
if (!careState || !careState.meals?.length) careState = { profile:{ ...D.EXAMPLE_PROFILE, reqs:[] }, meals: D.EXAMPLE_MEALS.map(fromCare), source:"example" };
careState.meals.forEach(reg);
const saveCare = () => store.set("care", careState);
let careView = "all", careCat = "all", careSort = "rec", carePage = 1, dash = null, tblSort = null;
const NAV = [["profile","My Nutrition Profile","M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0"],["all","Recommended Meals","M4 6h16M4 12h16M4 18h10"],["breakfast","Breakfast","M5 18h14M7 18a5 5 0 0110 0M12 6v3M6 9l1.5 1.5M18 9l-1.5 1.5"],["lunch","Lunch","M12 3v18M3 12h18"],["dinner","Dinner","M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"],["snacks","Healthy Snacks","M12 21c5 0 8-4 8-9-4 0-6 2-8 5-2-3-4-5-8-5 0 5 3 9 8 9z"],["saved","Saved Recipes","M12 21s-7-4.4-9.3-9A5.2 5.2 0 0112 6.5 5.2 5.2 0 0121.3 12C19 16.6 12 21 12 21z"],["dashboard","Nutrition Dashboard","M4 20V10M10 20V4M16 20v-7M22 20H2"]];
function countFor(v){ const m = careState.meals; return v === "all" ? m.length : v === "saved" ? Object.keys(saved).length : v === "snacks" ? m.filter(x => x.cat === "snacks" || x.cat === "dessert").length : CAT_LABEL[v] ? m.filter(x => x.cat === v).length : ""; }
function renderCareNav(){
  $("#careNav").innerHTML = NAV.map(([k,l,d], i) => `${i===1||i===6?'<div class="sep"></div>':""}<button data-v="${k}" aria-current="${careView===k?"page":"false"}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>${l}${countFor(k)!==""?`<span class="n">${countFor(k)}</span>`:""}</button>`).join("");
}
$("#careNav").addEventListener("click", e => { const b = e.target.closest("[data-v]"); if (!b) return; careView = b.dataset.v; carePage = 1; careCat = "all"; closeCareMenu(); renderCare(); window.scrollTo({ top:0 }); });
$("#careMenu").onclick = () => { const o = $("#careSide").classList.toggle("open"); $("#careMenu").setAttribute("aria-expanded", o); scrim.classList.toggle("on", o); };
function closeCareMenu(){ if ($("#careSide").classList.contains("open")) { $("#careSide").classList.remove("open"); $("#careMenu").setAttribute("aria-expanded","false"); if (!drawer.classList.contains("on")) scrim.classList.remove("on"); } }
scrim.addEventListener("click", closeCareMenu);
$$(".textsize button").forEach(b => b.onclick = () => { $$(".textsize button").forEach(x => x.setAttribute("aria-pressed", x === b)); $("#careRoot").classList.toggle("xl", b.dataset.size === "xl"); });
function profileChips(p){
  const t = [];
  if (p.example) t.push("Example profile");
  t.push(`${p.age} yrs`, p.sex === "male" ? "Male" : "Female", p.diet, ...(p.conditions||[]), ...(p.allergies||[]).map(a => `No ${a.toLowerCase()}`));
  return t.map(x => `<span>${esc(x)}</span>`).join("");
}
function reviewReasons(p){
  const r = [];
  (p.conditions||[]).filter(c => REVIEW_COND.includes(c)).forEach(c => r.push(`${c}: this usually needs an individual plan from a registered dietitian or your doctor.`));
  if (+p.age < 18) r.push("Under 18: growing children and teenagers have different needs from adults.");
  if (+p.age >= 75) r.push("Aged 75 or over: appetite, protein and fluid needs vary a lot from person to person.");
  if ((p.conditions||[]).length >= 3) r.push("Several conditions together can need trade-offs that only a professional can judge.");
  const bmi = p.weight / Math.pow(p.height/100, 2); if (bmi && bmi < 18.5) r.push(`Your BMI is about ${bmi.toFixed(1)}, which is underweight. A dietitian can help you gain safely.`);
  if (p.pro) r.push("You have instructions from a healthcare professional. Please check this plan against them.");
  return r;
}
function renderCare(){
  const p = careState.profile;
  renderCareNav();
  $("#careTitle").textContent = NAV.find(n => n[0] === careView)?.[1] || "";
  $("#careWho").innerHTML = careView === "profile" ? "" : profileChips(p) + `<button class="btn btn-ghost btn-sm" style="padding:3px 12px" data-edit>Edit profile</button>`;
  const rr = reviewReasons(p);
  $("#careReview").innerHTML = careView !== "profile" && (rr.length || careState.source === "example" || careState.removed) ? `
    ${careState.source === "example" ? `<div class="msg" style="margin-bottom:10px"><b>You're looking at an example plan</b> for a 62-year-old vegetarian woman with type 2 diabetes, low iron and a tree-nut allergy. <button class="btn btn-primary btn-sm" data-edit style="margin-inline-start:6px">Create my own plan</button></div>` : ""}
    ${careState.removed ? `<div class="msg" style="margin-bottom:10px">${esc(careState.removed)}</div>` : ""}
    ${rr.length ? `<div class="review"><span style="font-size:1.3rem">⚕</span><div><b>Have a professional review this plan</b>These meals are general suggestions. Show them to a registered dietitian or your doctor because:<ul>${rr.map(x => `<li>${esc(x)}</li>`).join("")}</ul></div></div>` : ""}` : "";
  const V = $("#careView");
  if (careView === "profile") V.innerHTML = profileForm(p);
  else if (careView === "all") V.innerHTML = allView();
  else if (careView === "saved") V.innerHTML = savedView();
  else if (careView === "dashboard") V.innerHTML = dashView();
  else V.innerHTML = catView(careView);
}
$("#careRoot").addEventListener("click", e => { if (e.target.closest("[data-edit]")) { careView = "profile"; renderCare(); window.scrollTo({ top:0 }); } });
function mealCard(R, i){ return recipeCard(reg(R), i, { badge:CAT_LABEL[R.cat], badgeCls:"green", why:R.why, cls:"mcard" }); }
const sorters = { rec:null, kcal:(a,b) => nut(a)[0]-nut(b)[0], protein:(a,b) => nut(b)[1]-nut(a)[1], fibre:(a,b) => nut(b)[4]-nut(a)[4], iron:(a,b) => nut(b)[5]-nut(a)[5], calcium:(a,b) => nut(b)[6]-nut(a)[6] };
const nutCache = new WeakMap(); const nut = R => { if (!nutCache.has(R)) nutCache.set(R, nutrition(R.ings, R.serves).v); return nutCache.get(R); };
function allView(){
  let list = careState.meals.filter(m => careCat === "all" || m.cat === careCat);
  if (sorters[careSort]) list = [...list].sort(sorters[careSort]);
  const per = 9, pages = Math.max(1, Math.ceil(list.length / per)); carePage = Math.min(carePage, pages);
  const shown = list.slice((carePage-1)*per, carePage*per);
  return `<div class="toolbar"><div class="chips" id="careCats">${[["all","All"],...CAT_PLAN.map(([k]) => [k, CAT_LABEL[k] + (k==="snacks"?"s":k==="dessert"?"s":"")])].map(([k,l]) => `<button class="chip" data-cat="${k}" aria-pressed="${careCat===k}">${l} <span class="note">${k==="all"?careState.meals.length:careState.meals.filter(m=>m.cat===k).length}</span></button>`).join("")}</div>
    <label class="row" style="gap:8px"><span class="note">Sort</span><select class="field" id="careSort" style="width:auto">${[["rec","Recommended order"],["kcal","Fewest calories"],["protein","Most protein"],["fibre","Most fibre"],["iron","Most iron"],["calcium","Most calcium"]].map(([k,l]) => `<option value="${k}"${k===careSort?" selected":""}>${l}</option>`).join("")}</select></label></div>
    <div class="cards" style="margin-top:16px">${shown.map(mealCard).join("") || `<div class="empty">No meals in this category yet.</div>`}</div>
    ${pages > 1 ? `<div class="pager" id="carePager">${Array.from({length:pages},(_,i) => `<button aria-current="${i+1===carePage}" data-pg="${i+1}">${i+1}</button>`).join("")}</div>` : ""}`;
}
function catView(v){
  const cats = v === "snacks" ? ["snacks","dessert"] : [v];
  return cats.map(c => { const list = careState.meals.filter(m => m.cat === c); return list.length ? `<div class="cat-sec">${cats.length>1?`<h3>${c==="dessert"?"Desserts that suit you":"Healthy snacks"}</h3>`:""}<div class="cards">${list.map(mealCard).join("")}</div></div>` : ""; }).join("") || `<div class="empty">No meals here yet. <button class="btn btn-primary btn-sm" data-edit>Build my plan</button></div>`;
}
function savedView(){
  const list = Object.values(saved);
  if (!list.length) return `<div class="empty"><b>No saved recipes yet</b>Tap the heart on any meal, fusion dish or recipe to keep it here.</div>`;
  const groups = [["care","From REPLATE CARE"],["fusion","Indian × Emirati fusion"],["smart","Smart Recipes"]];
  return groups.map(([k,l]) => { const g = list.filter(R => R.kind === k); return g.length ? `<div class="cat-sec"><h3>${l}</h3><div class="cards">${g.map((R,i) => recipeCard(reg(R), i, R.kind==="care" ? { badge:CAT_LABEL[R.cat], badgeCls:"green" } : {})).join("")}</div></div>` : ""; }).join("");
}
function dashView(){
  const p = careState.profile, T = targets(p), M = careState.meals;
  if (!dash) dash = { breakfast:M.find(m=>m.cat==="breakfast")?.id, lunch:M.find(m=>m.cat==="lunch")?.id, dinner:M.find(m=>m.cat==="dinner")?.id, snacks:M.find(m=>m.cat==="snacks")?.id, dessert:"" };
  const day = Object.values(dash).map(id => M.find(m => m.id === id)).filter(Boolean);
  const tot = [0,0,0,0,0,0,0,0]; day.forEach(R => nut(R).forEach((v,j) => tot[j] += v));
  let rows = M.map(R => ({ R, n:nut(R) }));
  if (tblSort != null) rows.sort((a,b) => tblSort === "name" ? a.R.name.localeCompare(b.R.name) : b.n[tblSort]-a.n[tblSort]);
  return `<div class="panel stack" style="gap:16px"><div><h3 style="font-size:1.2em">Your estimated daily targets</h3><p class="note">Based on your age, sex, weight, height and activity, using ICMR-NIN 2020 reference intakes and the Mifflin–St Jeor equation. Approximate.</p></div>
      <div class="targets">${NUT.map(([l,u],j) => `<div class="tgt"><span>${l}</span><b>${fmtN(T[j],j)}</b> <span style="display:inline">${u}</span></div>`).join("")}</div></div>
    <div class="panel stack" style="gap:16px"><div><h3 style="font-size:1.2em">Build a day from your meals</h3><p class="note">Pick one meal for each slot to see how the day adds up against your targets.</p></div>
      <div class="form-grid">${[["breakfast","Breakfast"],["lunch","Lunch"],["dinner","Dinner"],["snacks","Snack"],["dessert","Dessert (optional)"]].map(([k,l]) => `<div><label class="lbl" for="dd-${k}">${l}</label><select class="field" id="dd-${k}" data-slot="${k}"><option value="">None</option>${M.filter(m => m.cat === k).map(m => `<option value="${m.id}"${dash[k]===m.id?" selected":""}>${esc(m.name)}</option>`).join("")}</select></div>`).join("")}</div>
      <div class="bars">${NUT.map(([l,u],j) => { const pc = Math.round(tot[j]/T[j]*100); const over = (j===0||j===3) && pc > 105; return `<div class="bar"><span>${l}</span><div class="track"><div class="fill${over?" over":""}" style="width:${Math.min(100,pc)}%"></div></div><span class="val"><b>${fmtN(tot[j],j)}</b> / ${fmtN(T[j],j)} ${u}</span></div>`; }).join("")}</div>
      <p class="note">Green bars show progress toward a target; a clay bar means the day goes over your energy or fat target.</p></div>
    <div class="panel stack" style="gap:14px"><div><h3 style="font-size:1.2em">All ${M.length} meals at a glance</h3><p class="note">Per serving. Tap a column heading to sort, or a meal name to open it.</p></div>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th data-sort="name">Meal</th><th>Type</th>${NUT.map(([l,u],j) => `<th class="num" data-sort="${j}">${l.replace("Carbohydrates","Carbs").replace("Dietary fibre","Fibre").replace("Vitamin B12","B12").replace("Total fat","Fat")} (${u})</th>`).join("")}</tr></thead>
      <tbody>${rows.map(({R,n}) => `<tr><td><button class="lnk" data-open="${esc(R.id)}">${esc(R.name)}</button></td><td>${CAT_LABEL[R.cat]}</td>${n.map((v,j) => `<td class="num">${fmtN(v,j)}</td>`).join("")}</tr>`).join("")}</tbody></table></div></div>`;
}
$("#careView").addEventListener("click", e => {
  const c = e.target.closest("[data-cat]"); if (c) { careCat = c.dataset.cat; carePage = 1; renderCare(); return; }
  const g = e.target.closest("[data-pg]"); if (g) { carePage = +g.dataset.pg; renderCare(); $("#careTitle").scrollIntoView({ behavior:"smooth" }); return; }
  const s = e.target.closest("th[data-sort]"); if (s) { tblSort = s.dataset.sort === "name" ? "name" : +s.dataset.sort; renderCare(); return; }
  const o = e.target.closest(".opt-chip"); if (o) { const single = o.closest("[data-single]"); if (single) $$(".opt-chip", single).forEach(x => x.setAttribute("aria-pressed", x === o)); else o.setAttribute("aria-pressed", o.getAttribute("aria-pressed") !== "true"); }
});
$("#careView").addEventListener("change", e => {
  if (e.target.id === "careSort") { careSort = e.target.value; carePage = 1; renderCare(); }
  if (e.target.dataset.slot) { dash[e.target.dataset.slot] = e.target.value; renderCare(); }
});
const optChips = (name, list, sel, single) => `<div class="chips"${single?" data-single":""} data-name="${name}">${list.map(o => `<button type="button" class="chip opt-chip" aria-pressed="${(Array.isArray(sel)?sel:[sel]).includes(o)}">${esc(o)}</button>`).join("")}</div>`;
function profileForm(p){
  const blank = p.example;
  const v = (k, d="") => blank ? d : esc(p[k] ?? d);
  return `<form class="panel" id="careForm">
    <div class="fsec"><h3>About you</h3>
      ${blank ? `<p class="msg">The example profile is shown below so you can see how it works. Replace it with your own details.</p>` : ""}
      <div class="form-grid">
        <div><label class="lbl" for="cf-age">Age</label><input class="field" id="cf-age" type="number" min="1" max="110" required value="${esc(p.age)}"></div>
        <div><label class="lbl" for="cf-sex">Sex</label><select class="field" id="cf-sex"><option value="female"${p.sex!=="male"?" selected":""}>Female</option><option value="male"${p.sex==="male"?" selected":""}>Male</option></select></div>
        <div><label class="lbl" for="cf-act">Activity</label><select class="field" id="cf-act">${[["sedentary","Mostly sitting"],["light","Lightly active"],["moderate","Moderately active"],["active","Very active"]].map(([k,l]) => `<option value="${k}"${p.activity===k?" selected":""}>${l}</option>`).join("")}</select></div>
        <div><label class="lbl" for="cf-w">Weight (kg)</label><input class="field" id="cf-w" type="number" min="20" max="250" value="${esc(p.weight)}"></div>
        <div><label class="lbl" for="cf-h">Height (cm)</label><input class="field" id="cf-h" type="number" min="90" max="230" value="${esc(p.height)}"></div>
      </div></div>
    <div class="fsec"><h3>What you eat</h3>
      <fieldset><legend>Diet type</legend>${optChips("diet", OPTS.diet, p.diet, true)}</fieldset>
      <fieldset><legend>Dietary requirements</legend>${optChips("reqs", OPTS.reqs, p.reqs||[])}</fieldset>
      <fieldset><legend>Preferred cuisines</legend>${optChips("cuisines", OPTS.cuisines, p.cuisines||[])}</fieldset>
      <div class="form-grid"><div class="span3"><label class="lbl" for="cf-likes">Foods you enjoy</label><input class="field" id="cf-likes" value="${v("likes", "")}" placeholder="e.g. dosa, dal, grilled fish, light dinners"></div></div></div>
    <div class="fsec"><h3>Health and safety</h3>
      <fieldset><legend>Health conditions</legend>${optChips("conditions", OPTS.conditions, p.conditions||[])}</fieldset>
      <fieldset><legend>Food allergies and intolerances</legend>${optChips("allergies", OPTS.allergies, p.allergies||[])}</fieldset>
      <div class="form-grid">
        <div class="span3"><label class="lbl" for="cf-aother">Other allergies or intolerances</label><input class="field" id="cf-aother" value="${v("allergyOther")}" placeholder="e.g. mustard, mango"></div>
        <div class="span3"><label class="lbl" for="cf-avoid">Foods you need to avoid</label><input class="field" id="cf-avoid" value="${v("avoid")}" placeholder="Separate with commas, e.g. brinjal, red meat, pickles"></div>
      </div>
      <fieldset><legend>Nutritional goals</legend>${optChips("goals", OPTS.goals, p.goals||[])}</fieldset>
      <div><label class="lbl" for="cf-pro">Instructions from your doctor or dietitian</label><textarea class="field" id="cf-pro" placeholder="e.g. Limit potassium. No more than 30 g carbohydrate per meal.">${v("pro")}</textarea></div></div>
    <div class="fsec"><div class="row"><button class="btn btn-primary" type="submit" id="cfGo">Save and create my 25 meals</button><span class="note">Takes about a minute. Every meal is checked against your allergies and diet before it is shown.</span></div><div id="cfProgress"></div></div>
  </form>`;
}
$("#careView").addEventListener("submit", e => { if (e.target.id === "careForm") { e.preventDefault(); submitProfile(); } });
function readProfile(){
  const sel = n => $$(`[data-name="${n}"] .opt-chip[aria-pressed="true"]`).map(b => b.textContent.trim());
  return { age:+$("#cf-age").value || 40, sex:$("#cf-sex").value, activity:$("#cf-act").value, weight:+$("#cf-w").value || 60, height:+$("#cf-h").value || 160,
    diet: sel("diet")[0] || "Vegetarian", reqs:sel("reqs"), cuisines:sel("cuisines"), likes:$("#cf-likes").value.trim(), conditions:sel("conditions"), allergies:sel("allergies"),
    allergyOther:$("#cf-aother").value.trim(), avoid:$("#cf-avoid").value.trim(), goals:sel("goals"), pro:$("#cf-pro").value.trim() };
}
function profileText(p){
  const T = targets(p);
  return `Age ${p.age}, ${p.sex}, ${p.weight} kg, ${p.height} cm, activity ${p.activity}. Diet: ${p.diet}. Requirements: ${p.reqs.join(", ")||"none"}. Health conditions: ${p.conditions.join(", ")||"none"}. Allergies/intolerances: ${[...p.allergies, p.allergyOther].filter(Boolean).join(", ")||"none"}. Must avoid: ${p.avoid||"nothing listed"}. Goals: ${p.goals.join(", ")||"general health"}. Likes: ${p.likes||"not stated"}. Preferred cuisines: ${p.cuisines.join(", ")||"Indian and Emirati"}. Professional instructions: ${p.pro||"none"}.
Approximate daily targets: ${NUT.map(([l,u],j) => `${l} ${fmtN(T[j],j)} ${u}`).join(", ")}.`;
}
async function submitProfile(){
  const p = readProfile(), btn = $("#cfGo"), prog = $("#cfProgress");
  btn.disabled = true;
  if (!cap.sample) {
    const ex = D.EXAMPLE_MEALS.map(fromCare), ok = ex.filter(R => !conflictsOf(R, p).length);
    careState = { profile:p, meals:ok, source:"filtered", removed:`AI meal generation needs this page open on claude.ai. Showing the ${ok.length} example meals that fit your profile${ex.length-ok.length ? ` (${ex.length-ok.length} were removed because they conflict with your allergies or diet)` : ""}.` };
    saveCare(); careState.meals.forEach(reg); careView = "all"; dash = null; renderCare(); return;
  }
  const steps = [...CAT_PLAN.map(([k,n]) => [k, `${CAT_LABEL[k]}${k==="snacks"||k==="dessert"?"s":""} (${n})`]), ["check","Safety check against your allergies and diet"]];
  const paint = (now, done) => prog.innerHTML = `<div class="progress" style="margin-top:14px">${steps.map(([k,l],i) => `<div class="step ${i<done?"done":i===now?"now":""}"><i>${i<done?"✓":i+1}</i>${l}</div>`).join("")}</div>`;
  const meals = [], removed = [];
  const lang = replyLang();
  const gen = async (cat, n) => {
    const res = await askJSON(`You are REPLATE CARE, a careful, evidence-based nutrition assistant for Indian and UAE households. Recommend ${n} ${CAT_LABEL[cat].toLowerCase()} ${cat==="dessert"?"options (nutritionally suitable, small portions)":"meals"} for this person.
PERSON: ${profileText(p)}
HARD RULES:
- Never include any ingredient that conflicts with their allergies, intolerances, diet type, requirements or foods to avoid.
- Follow professional instructions exactly. Base choices on reliable clinical nutrition guidance (ICMR-NIN, ADA, WHO). Do not treat everyone with the same condition identically: use their age, sex, goals and preferences.
- Never claim a meal treats, cures or prevents a disease.
- Each meal must be a version of one dish from this PHOTO LIBRARY so the photo is accurate; set "photo" to its key. Use each key at most once here and don't repeat these meals: ${meals.map(m => m.name).join(", ") || "none yet"}.
  PHOTO LIBRARY: ${dishLibrary(p)}
- Quantities for ONE serving in grams. Use ingredient keys from this list when they match (else k:null): ${ING_KEYS}
- Prefer their cuisines and liked foods; vary grains, pulses, proteins and vegetables.
- "why": 1–2 plain sentences to "you", naming the specific need it serves.
Write text in ${lang}.
Return JSON: {"meals":[{"name":string,"photo":key,"desc":max 15 words,"why":string,"prep":minutes,"cook":minutes,"difficulty":"Easy"|"Medium"|"Hard","ings":[{"k":key|null,"name":string,"qty":household measure,"g":number}]}]}`);
    return (res?.meals||[]).map(m => fromCare({ ...m, id:uid("c"), cat }));
  };
  try {
    for (let i = 0; i < CAT_PLAN.length; i++) {
      const [cat, n] = CAT_PLAN[i]; paint(i, i);
      const got = await gen(cat, n);
      got.forEach(R => { const c = conflictsOf(R, p); if (c.length) removed.push(`${R.name}: ${c[0]}`); else meals.push(R); });
    }
    paint(CAT_PLAN.length, CAT_PLAN.length);
    for (let tries = 0; tries < 2 && meals.length < 25; tries++) {
      const short = CAT_PLAN.map(([k,n]) => [k, n - meals.filter(m => m.cat === k).length]).filter(([,d]) => d > 0);
      for (const [cat, d] of short) { const got = await gen(cat, d); got.forEach(R => { if (!conflictsOf(R, p).length) meals.push(R); else removed.push(R.name); }); }
    }
    paint(steps.length, steps.length);
    careState = { profile:p, meals, source:"ai", removed: removed.length ? `REPLATE removed ${removed.length} suggestion${removed.length>1?"s":""} that conflicted with your profile and replaced ${removed.length>1?"them":"it"}.` : null };
    saveCare(); meals.forEach(reg); careView = "all"; careCat = "all"; dash = null; renderCare(); window.scrollTo({ top:0 });
  } catch(e){ prog.innerHTML = `<div class="msg warn" style="margin-top:12px">${esc(errMsg(e))}${meals.length ? ` ${meals.length} meals were created before the error.` : ""}</div>`;
    if (meals.length) { careState = { profile:p, meals, source:"ai", removed:"Generation stopped early. Try again to complete all 25 meals." }; saveCare(); meals.forEach(reg); }
    btn.disabled = false; }
}
async function loadCareDetail(R){
  if (!cap.sample) { R.detailError = "The full method and personal explanation are written by AI. Open this page on claude.ai to load them. Nutrition and ingredients above are already complete."; if (drR === R) renderDrawer(); return; }
  R.loading = true; R.detailError = null; if (drR === R) renderDrawer();
  const p = careState.profile, n = nutrition(R.ings, 1).v;
  try {
    const d = await askJSON(`You are REPLATE CARE. Write the full recipe and a personalised explanation for this meal.
PERSON: ${profileText(p)}
MEAL: ${R.name} (${CAT_LABEL[R.cat]}). One serving. Ingredients: ${R.ings.map(i => `${i.label} (${i.g} g)`).join("; ")}.
Calculated nutrition per serving: ${NUT.map(([l,u],j) => `${l} ${fmtN(n[j],j)} ${u}`).join(", ")}.
Use these exact numbers in explanations. No claims that food treats, cures or prevents disease. Alternatives must respect the person's allergies, diet and foods to avoid. Write in ${replyLang()}, in plain words.
Return JSON: {"prepSteps":[2-4 preparation steps],"steps":[4-7 detailed cooking steps],"why":{"needs":string,"preferences":string,"nutrients":string,"benefits":string,"restrictions":string},"benefits":[{"nutrient":string,"text":string}],"alts":[{"from":string,"to":string,"effect":"how nutrition and taste change"}],"review":string|null (when a dietitian should check this specific meal for this person)}`);
    Object.assign(R, { prepSteps:d.prepSteps||[], steps:d.steps||[], aiWhy:d.why||{}, aiBenefits:d.benefits||[], aiAlts:d.alts||[], review:d.review||null, loading:false });
    saveCare(); if (saved[R.id]) { saved[R.id] = R; store.set("saved", saved); }
  } catch(e){ R.loading = false; R.detailError = errMsg(e); }
  if (drR === R) renderDrawer();
}

/* ---------- Cuisine Explorer ---------- */
const CUISINE = [
  ["in","biryani","Telangana","Layered basmati and marinated meat, sealed and slow-cooked (dum) with saffron, fried onions and mint.","90 min"],
  ["in","masala_dosa","Karnataka","Crisp fermented rice-and-urad crepe folded around spiced potato, with coconut chutney and sambar.","40 min*"],
  ["in","rogan_josh","Kashmir","Lamb braised in yoghurt with Kashmiri chilli, fennel and dry ginger for a deep red, mild gravy.","2 hr"],
  ["in","dhokla","Gujarat","Steamed, spongy gram-flour cake finished with mustard seeds, curry leaves and green chilli.","35 min"],
  ["in","fish_curry","Kerala","Fish simmered in coconut milk with kokum or tamarind, curry leaves and chilli.","40 min"],
  ["in","pav_bhaji","Mumbai","Mashed spiced vegetables cooked on a big tawa, served with buttered soft rolls.","45 min"],
  ["in","dal_makhani","Punjab","Whole black urad and rajma simmered for hours with tomato, butter and cream.","3 hr*"],
  ["in","ragi_mudde","Karnataka","Steamed finger-millet balls eaten with sambar or saaru. A rural Karnataka staple.","25 min"],
  ["in","haleem","Hyderabad","Wheat, lentils and meat slow-cooked and pounded smooth, eaten through Ramadan.","4 hr"],
  ["ae","machboos","UAE","The Emirati national dish: rice cooked in spiced chicken broth with loomi and bzar.","80 min"],
  ["ae","harees","UAE","Wheat and meat slow-cooked and beaten to a smooth porridge, served at Ramadan and Eid.","4 hr"],
  ["ae","luqaimat","UAE","Crisp saffron-cardamom dumplings drizzled with date syrup and sesame.","1 hr"],
  ["ae","balaleet","UAE","Sweet saffron vermicelli with rose water and cardamom, topped with a thin omelette.","25 min"],
  ["ae","thareed","UAE","Thin regag bread soaked in a meat and vegetable saloona stew. A Ramadan favourite.","90 min"],
  ["ar","kabsa","Saudi Arabia","Spiced rice with chicken or lamb, tomato, raisins and toasted almonds on one big platter.","75 min"],
  ["ar","mandi","Yemen","Rice and meat slow-cooked in a pit oven so the meat drips its juices into the rice. Popular across the UAE.","3 hr"],
  ["ar","kunafa","Levant","Shredded kataifi pastry baked crisp around soft cheese and soaked in syrup.","1 hr"],
  ["ar","umm_ali","Egypt","Pastry baked in sweetened milk with nuts, raisins and coconut. A Gulf favourite at iftar.","45 min"],
];
const CTABS = [["all","All dishes"],["in","Indian regional"],["ae","Emirati & Arabian"]];
let cTab = store.get("cTab","all");
function renderCuisine(){
  $("#cTabs").innerHTML = CTABS.map(([k,l]) => `<button role="tab" aria-selected="${k===cTab}" data-tab="${k}">${l}</button>`).join("");
  $("#cCards").innerHTML = CUISINE.filter(d => cTab === "all" || (cTab === "in" ? d[0] === "in" : d[0] !== "in")).map((d,i) => `<article class="rcard" style="animation-delay:${(i%6)*60}ms">
    <div class="pic"><img class="ph" src="${dishPhoto(d[1])}" alt="${esc(D.DISH[d[1]][0])}" loading="lazy"></div>
    <div class="bd"><span class="region">${esc(d[2])}</span><h3>${esc(D.DISH[d[1]][0])}</h3><p class="desc">${esc(d[3])}</p>
    <div class="foot"><span class="note">⏱ ${d[4]}</span><button class="btn btn-ghost btn-sm" data-ask="${esc(D.DISH[d[1]][0])}">Get recipe</button></div></div></article>`).join("");
}
$("#cTabs").addEventListener("click", e => { const b = e.target.closest("[data-tab]"); if (b) { cTab = b.dataset.tab; store.set("cTab", cTab); renderCuisine(); } });
$("#cCards").addEventListener("click", e => { const b = e.target.closest("[data-ask]"); if (b) { openChat(); sendChat(`Give me a home recipe for ${b.dataset.ask} for 4 people, with ingredients and steps.`); } });

/* ---------- Credits ---------- */
let creditsLoaded = false;
async function loadCredits(){
  if (creditsLoaded) return; creditsLoaded = true;
  const tb = $("#creditTbl tbody"); tb.innerHTML = `<tr><td colspan="5">${loadingHTML("Loading credits…")}</td></tr>`;
  try {
    const c = await (await fetch("img/credits.json")).json();
    tb.innerHTML = Object.entries(c).sort().map(([k,v]) => { const [t,key] = k.split("/"); const what = t === "i" ? ingName(key) : D.DISH[key]?.[0] || key;
      return `<tr><td><img src="img/${k}.jpg" alt="" style="width:56px;height:42px;object-fit:cover;border-radius:8px" loading="lazy"></td><td>${esc(what)}</td><td><a href="https://commons.wikimedia.org/wiki/File:${encodeURIComponent(v.file)}" target="_blank" rel="noopener">${esc(v.file)}</a></td><td>${esc(v.artist||"See file page")}</td><td>${esc(v.license||"See file page")}</td></tr>`; }).join("");
  } catch { tb.innerHTML = `<tr><td colspan="5">Couldn't load the credits list. Refresh the page to try again.</td></tr>`; creditsLoaded = false; }
}

/* ---------- Chat ---------- */
const chat = $("#chat"), msgs = $("#chatMsgs");
let history = [];
const SUGS = ["What can I make with stale bread?","How long does cooked rice keep?","Substitute for cream in curry?","What is loomi and how do I use it?"];
$("#chatSugs").innerHTML = SUGS.map(s => `<button type="button">${s}</button>`).join("");
$("#chatSugs").addEventListener("click", e => { if (e.target.matches("button")) sendChat(e.target.textContent); });
function bubble(container, who, text){ const d = document.createElement("div"); d.className = "bub " + who; d.textContent = text; container.append(d); container.scrollTop = container.scrollHeight; return d; }
bubble(msgs, "ai", "Hi! I'm REPLATE Chef. Ask me anything about cooking, swaps, storage or using up leftovers.");
function openChat(){ chat.classList.add("open"); chat.setAttribute("aria-hidden","false"); $("#fab").setAttribute("aria-expanded","true"); $("#fab .badge")?.remove(); setTimeout(() => $("#chatInput").focus(), 300); }
function closeChat(){ chat.classList.remove("open"); chat.setAttribute("aria-hidden","true"); $("#fab").setAttribute("aria-expanded","false"); }
$("#fab").onclick = () => chat.classList.contains("open") ? closeChat() : openChat();
$("#chatClose").onclick = closeChat;
const SYS = lang => `You are REPLATE Chef, a warm, practical cooking assistant focused on Indian, Emirati/Arabian and Indian–Emirati fusion home cooking and on reducing food waste. Answer cooking, food storage, substitution and nutrition questions concisely (under 150 words unless a full recipe is requested). Use short lists for recipes. Never claim a food treats or cures disease. Politely steer off-topic questions back to food. Reply in ${lang}.`;
async function streamAnswer(hist, lang, el){
  if (!cap.sample) { el.textContent = "I can only answer when this page is open on claude.ai with Claude access allowed. Meanwhile, browse the Cuisine Explorer or the fusion recipes."; return null; }
  const input = [{ role:"user", content: SYS(lang) + "\n\nUser: " + hist[0].content }, ...hist.slice(1)];
  try { const res = await cap.sample(input, { cache:false, onText: ({text}) => { el.textContent = text; el.parentElement.scrollTop = el.parentElement.scrollHeight; } }); el.textContent = res.text; return res.text; }
  catch(e){ el.textContent = errMsg(e); return null; }
}
let chatBusy = false;
async function sendChat(q){
  q = q.trim(); if (!q || chatBusy) return; chatBusy = true; $("#chatSugs").hidden = true;
  bubble(msgs, "me", q); history.push({ role:"user", content:q });
  const el = bubble(msgs, "ai", "Thinking…");
  const ans = await streamAnswer(history.slice(-10).filter((m,i) => i>0 || m.role==="user"), replyLang(), el);
  if (ans) history.push({ role:"assistant", content:ans }); else history.pop();
  chatBusy = false;
}
$("#chatForm").addEventListener("submit", e => { e.preventDefault(); const i = $("#chatInput"); sendChat(i.value); i.value = ""; });

/* ---------- Voice ---------- */
const VLANGS = [["en","English","English"],["hi","हिन्दी","Hindi"],["ar","العربية","Arabic"],["ta","தமிழ்","Tamil"],["ml","മലയാളം","Malayalam"],["ur","اردو","Urdu"]];
let vLang = store.get("vLang","en");
function renderVLangs(){ $("#vLangs").innerHTML = VLANGS.map(([k,n,e]) => `<button aria-pressed="${k===vLang}" data-l="${k}"><b>${n}</b><span>${e}</span></button>`).join(""); }
$("#vLangs").addEventListener("click", e => { const b = e.target.closest("[data-l]"); if (b) { vLang = b.dataset.l; store.set("vLang",vLang); renderVLangs(); } });
const convo = $("#vConvo");
let vHist = [], partialEl = null, vBusy = false, finalText = "";
function vIntro(){ convo.innerHTML = ""; bubble(convo, "ai", "Namaste, marhaba, hello! Ask me how to cook something, what to swap, or how to store leftovers."); }
$("#vClear").onclick = () => { vHist = []; vIntro(); cap.tts?.stop?.(); };
async function speak(text, btn){ if (!cap.tts) return; try { await cap.tts.speak(text.slice(0,2000), { language: vLang }); } catch(e){ if (e?.code === "not_granted" && btn) btn.remove(); } }
async function askVoice(q){
  q = q.trim(); if (!q || vBusy) return; vBusy = true;
  bubble(convo, "me", q); vHist.push({ role:"user", content:q });
  const el = bubble(convo, "ai", "Thinking…");
  const ans = await streamAnswer(vHist.slice(-10).filter((m,i) => i>0 || m.role==="user"), LANG_NAME[vLang], el);
  if (ans) { vHist.push({ role:"assistant", content:ans });
    if (cap.tts) { const b = document.createElement("button"); b.className = "speak"; b.textContent = "🔊 Play again"; b.onclick = () => speak(ans, b); el.append(document.createElement("br"), b); speak(ans, b); } }
  else vHist.pop();
  vBusy = false;
}
$("#vForm").addEventListener("submit", e => { e.preventDefault(); const i = $("#vInput"); askVoice(i.value); i.value = ""; });
function setupDictation(){
  const d = cap.dictation; if (!d) return;
  d.onPartial(({text}) => { if (!partialEl) partialEl = bubble(convo, "me partial", ""); partialEl.textContent = (finalText + " " + text).trim(); convo.scrollTop = convo.scrollHeight; });
  d.onFinal(({text}) => { finalText = (finalText + " " + text).trim(); if (partialEl) partialEl.textContent = finalText; });
  d.onState(({state}) => {
    const live = state === "listening"; $("#micBtn").classList.toggle("live", live); $("#micState").textContent = live ? "Listening… tap to send" : "Tap to speak";
    if (!live && state !== "starting") { partialEl?.remove(); partialEl = null; if (finalText) { const q = finalText; finalText = ""; askVoice(q); } }
  });
}
$("#micBtn").addEventListener("click", () => {
  const d = cap.dictation; if (!d) return;
  if ($("#micBtn").classList.contains("live")) { d.stop().catch(()=>{}); return; }
  cap.tts?.stop?.(); finalText = "";
  d.start({ language: vLang }).catch(e => {
    if (e?.code === "not_granted") { $("#micBtn").disabled = true; $("#micState").textContent = "Microphone access was declined"; $("#micNote").textContent = "You can still type your question."; }
    else $("#micNote").textContent = "Couldn't start the microphone. Tap to try again, or type below.";
  });
});
function refreshAvailability(){
  $("#scanBtn").hidden = !(cap.images && ingPhotos.length);
  if (!cap.dictation) { $("#micBtn").disabled = true; $("#micState").textContent = "Voice input isn't available here"; $("#micNote").textContent = "Open this page in Chrome, Edge or the Claude desktop app to speak. You can still type below."; }
  else { $("#micBtn").disabled = false; $("#micState").textContent = "Tap to speak"; }
}

/* ---------- Boot ---------- */
applyTheme(); applyLang(uiLang); updSaved();
renderMyIngs(); renderPantry();
renderRecipes(D.LOCAL_RECIPES.map((r,i) => fromSmart({ ...r, id:"local"+i })), "Recipe ideas", "Example recipes for the sample ingredients above. Press Generate for your own.");
renderFz(); renderLeftovers(); renderFzMine(); renderCuisine(); renderVLangs(); vIntro(); renderCare();
route(); refreshAvailability();
})();
